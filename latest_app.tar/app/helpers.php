<?php
use App\Models\Product;
use App\Models\User;
use App\Models\Exercise;
use App\Models\SubExercise;
use Carbon\Carbon;

function totalProduct()
{
   return Product::count();
}

function totalProductAddedAdmin()
{
   $authId  =  Auth::user()->id;
   return Product::where('added_by',$authId)->count();
}

function totalProductAddedUser()
{
   $authId  = Auth::user()->id;
   return Product::where('added_by','!=',$authId)->count();
}

function totalUser()
{
   return User::role('user')->count();
}

function totalExercise()
{
   return Exercise::count();
}

function getExercise()
{
      $exInfo = DB::select("SELECT DISTINCT exercises.id as exId,exercises.name as exName, 
      (SELECT COUNT(*) FROM sub_exercises
      WHERE sub_exercises.exercise_id = exercises.id) AS Total
      FROM exercises");
      return $exInfo;         
}

function getPic()
{
   $image = Auth::user()->profile_img;
   return $image; 
}

function todayUsers()
{
   return User::select('name','created_at')->whereDate('created_at', Carbon::today())->get();
}


function todayProducts()
{
  return Product::select('name','created_at')->whereDate('created_at', Carbon::today())->get();  
}

 







