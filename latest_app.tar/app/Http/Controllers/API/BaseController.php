<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Notification;

class BaseController extends Controller
{
     
    /**
     * return error response.
     *
     * @return \Illuminate\Http\Response
     */

    public function sendResponse($statusCode, $msg, $data)
    {
        return response()->json([
            "status" => $statusCode,
            "message" => $msg,
            "data" => $data
        ],$statusCode);

    }

    
    public function generateNumericOTP()
    {
         $n         = 4; 
         $generator = "1357902468";  
         $result    = ""; 
    
        for ($i = 1; $i <= $n; $i++) { 
            $result .= substr($generator, (rand()%(strlen($generator))), 1); 
        } 
        
        return $result; 
    } 


    public function NullToArray($data)
    {
           array_walk_recursive($data, function(&$item) {
           $item = strval($item);
        });

       return $data;
    }

}
