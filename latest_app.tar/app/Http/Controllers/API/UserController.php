<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use App\Models\User;
use App\Models\ViewVideo;
use App\Models\SubExercise;
use App\Models\Notification;
use App\Models\Goal;
use Validator,Mail,File;


class UserController extends BaseController
{
    public function __construct(User $user, ViewVideo $viewvideo, Goal $Goal){
        $this->user          =     $user;
        $this->viewVideo     =     $viewvideo;
        $this->goal          =     $Goal;
    }

    public function register(Request $request){   
        $request['role']      =   'user';
        $validator            =   Validator::make($request->all(), [
         'name'               =>  'required',
         'email'              =>  'required|email|unique:users',
          //'device_type'      =>  'required',
          //'device_token'     =>  'required',
         'password'           =>  'required|min:8|same:confirm_password'
        ]);

        if($validator->fails()){
           return $this->sendResponse(400, $validator->messages()->first(), $this->NullToArray($request->only('name','email'))); 
        }

        try{
           $res  =  $this->user->add($request->all());
           if($res['status']){
                    //$userData = $this->user->find($res['UserId']);
                    $res['return']->token = $res['return']->createToken('fitness-app')->accessToken;
                    //$device_token     =  $request->device_token;
                    //$sender_id        =  1;
                    //$receiver_id      =  $res['UserId'];
    
                    // $dataArr = array(
                    //     'message'  =>'Welcome to our fitnessApp',
                    //     'body'     => 'hi',
                    // );
                    // $payload = array(
                    //     'payload' => "1",
                    //     'id'      => $receiver_id 
                    // );                
                    // $notires    =   $this->sendNotification($device_token, $dataArr, $payload);
               
                    // if($notires)
                    // {      
                    //     $type   = 'Registration';
                    //     $title  = 'User Registration'; 
                    //     $this->entryNotification($sender_id, $receiver_id, $type, $title, $payload, $dataArr);
                    // }

                      $userData   =  $res['return']->toArray();
                      $userData = $this->NullToArray($userData);
 
                   return $this->sendResponse(200,'User added successfully',$userData);
           }
           else
           return $this->sendResponse(500,'Something went wrong','');

        }catch(\Throwable $th){
           return $this->sendResponse(500,'Something went wrongaa',$th->getMessage());
        }
    }


    public function login(request $request){
        $validator         =     Validator::make($request->all(),[
           'email'         =>    'required',
           'password'      =>    'required' 
        ]);

        if($validator->fails()){
            return $this->sendResponse(400,$validator->messages()->first(),$this->NullToArray($request->only('email')));
        }
        try{
            $res = $this->user->login($request->all());
            if($res['status']){
                  $userData = $this->user->find($res['UserId']);
                  $userData->token = $userData->createToken('fitness-app')->accessToken;
                  $userData = $userData->toArray();
                  $userData = $this->NullToArray($userData);

                return $this->sendResponse(200,'User login successfully',$userData);   
            }
            else
            return $this->sendResponse(401,'Unauthorized',$this->NullToArray($request->only('email')));

        }catch(\Throwable $th){
            return $this->sendResponse(500,'Something went wrong',$th);
        }
    }


    public function viewProfile(){  
        try{
            $obj      =   auth()->guard("api")->user();
            $obj->profile;
            $data     =  $obj->toArray();

             //$obj             =     $this->user::with('profile')->find($id);
             $allvideos       =     $this->viewVideo::
             join("sub_exercises", "view_videos.video_id", '=', "sub_exercises.id")
             ->where("view_videos.user_id",$obj->id)->get();

             $data      = $this->NullToArray($data);

             $allvideos = $this->NullToArray($allvideos); 

            $data['allvideos']  = $allvideos;

             if($data)
              return $this->sendResponse(200,'User view profile',$data);
             else
              return $this->sendResponse(401,'Unauthorized','');  

           }catch(\Throwable $th){
             return $this->sendResponse(500,'Something went wrong',$th);  
           }
     }
     

    public function updateProfile(request $request){

        $obj      =   auth()->guard("api")->user();
        $obj->profile;
        $validator    =  Validator::make($request->all(),[
            'name'               =>  'required',
           // 'email'              =>  'required|email|unique:users,email,'.$obj->id,
           'gender'              =>  'in:Male,Female,Other',
            'device_token'       =>  'nullable',  
        ]);

        if($validator->fails()){
            $data  = $request->toArray();
            $data      = $this->NullToArray($data);
            return $this->sendResponse(400,$validator->messages()->first(),$data);
        }

        try{
            $res = $this->user->updateUser($request->all(), $obj->id);
            if($res['status']){
                $data      = $obj->toArray();
                $data      = $this->NullToArray($data);
                return $this->sendResponse(200,'Your profile updated successfully', $data);
            }
            else
            return $this->sendResponse(500,'Something went wrong',$this->NullToArray($request->all()));
        }catch(\Throwable $th){
            return $this->sendResponse(500,'Something went wrong',$th);
        }
    }


    public function changePassword(request $request){
            
            $validator        =    Validator::make($request->all(), [
              'password'      =>    'required|min:8|same:confirm_password'
            ]);

            if($validator->fails()){
                 return $this->sendResponse(400,$validator->messages()->first(),"");
            }

            try{
                $obj      =   auth()->guard("api")->user();
                $res      =  $this->user->changePass($request->all(),  $obj->id);
                if($res['status']){
                    $data = $obj->toArray();
                    $data = $this->NullToArray($data);
                    return $this->sendResponse(200,'Password changed successfully',$data); 
                }
                else
                return $this->sendResponse(500,'Something went wrong',$this->NullToArray($request->all()));

            }catch(\Throwable $th){
                 return $this->sendResponse(500,'Something went wrong',$th);
            }
    }


    public function forgotPassword(request $request){ 
    
      $validator      =   Validator::make($request->all(),[
          'email'    =>   'required|email'
      ]);

      if($validator->fails()){
            return $this->sendResponse(400,$validator->messages()->first(),$this->NullToArray($request->all()));
      }else{
      try{
        $res  = $this->user->forgotPass($request->all()); 
        if($res['status']){
                $user   =  array('name' => $res['otp']->name,'email' => $res['otp']->email,'otp'=>$res['otp']->otp);
                Mail::send('emails.forgot-password-otp', ['user' => $user], function ($m) use ($user) {
                $m->from('admin@fitness.com', 'Fitness App');
                $m->to($user['email'], $user['name'])->subject('OTP for forgot password');
                });
                    $newarry['email']   = $res['otp']->email;
                    $newarry['otp']   = $res['otp']->otp;
                    // $res['otp']->profile;
                   //$res['otp']->token = $res['otp']->createToken('fitness-app')->accessToken;

                $newarry = $this->NullToArray($newarry);
                return $this->sendResponse(200,'OTP sent successfully',$newarry); 
        }else{
            return $this->sendResponse(404,'Email not exit in our record',$this->NullToArray($request->all())); 
        }
      }catch(\Throwable $th){
            return $this->sendResponse(500,'Something went wrong',$th);
        }
      }
    }


    public function verifyOTP(request $request){
        
        $validator     =   validator::make($request->all(), [
            'email'          => 'required|email',
            'otp'            => 'required|numeric',
        ]);

        if($validator->fails()){
            return $this->sendResponse(400,$validator->messages()->first(),$this->NullToArray($request->all()));
        }

        try{
            $obj   =   User::where('email', $request->email)->where('otp', $request->otp)->first();
            if($obj){  
            //    $baseobj     =  new BaseController();
             //   $otp       =  $baseobj->generateNumericOTP();
             //   $obj->otp  =  $otp;
             //   $obj->save();
             $data  = $request->toArray();
             $data  = $this->NullToArray($data);
                 return $this->sendResponse(200,'OTP verified successfully',$data);
            }else{
                 return $this->sendResponse(401,'OTP not match with us', $this->NullToArray($request->all()));  
            }
          }catch(\Throwable $th){
            return $this->sendResponse(500,'Something went wrong', $th);
        }
    }


    public function resetPassword(request $request){

        $validator         =   validator::make($request->all(), [
            'email'        => 'required|email',
            'otp'          => 'required|numeric',
            'password'     => 'required|min:8|same:confirm_password'  
        ]);

        if($validator->fails()){
            return $this->sendResponse(400,$validator->messages()->first(),$this->NullToArray($request->only('email','otp')));
        }

        try{
            $res   =  $this->user->resetPass($request->all());
            if($res['status']){
                 //$res['data']->profile;
                 //$data = $request->toArray();
                 $newarr['email']  = $request->email;
                 $newarr = $this->NullToArray($newarr);
                 return $this->sendResponse(200, $res['msg'], $newarr);
            }
            else
            return $this->sendResponse(401,$res['msg'], "");  
            
          }catch(\Throwable $th){
            return $this->sendResponse(500,'Something went wrong', $th);
        }
    }


    public function userViewVideo(request $request){

        $validator          =   Validator::make($request->all(), [
            'user_id'       =>   'required',
            'video_id'      =>   'required'  
        ]); 

        if($validator->fails()){
          return $this->sendResponse(400,$validator->messages()->first(),$this->NullToArray($request->all())); 
        }

        try{
           $chkvid   =  $this->viewVideo::where('user_id',$request->user_id)->where('video_id',$request->video_id)->first();
           if($chkvid){
               return $this->sendResponse(208,'Video already added in view list',$this->NullToArray($request->all()));
           }
           else{
               $obj               =   new $this->viewVideo;
               $obj->user_id      =   $request->user_id;
               $obj->video_id     =   $request->video_id;
               $obj->save();
             return $this->sendresponse(200,'Video added in view list',$this->NullToArray($request->all()));
          } 
        }catch(\Throwable $th){
            return $this->sendResponse(500, 'Something went wrong', $th); 
        }
    }

    public function socialLogin(request $request){
      
        if($request->social_type=='facebook'){
            $validator   = Validator::make($request->all(),[
                'social_type'      => 'required',
                'facebook_token'   => 'required',
            ]); 
        }
        else{
            $validator   = Validator::make($request->all(),[
                'social_type'      => 'required|in:google',
                'google_token'     => 'required',
            ]); 
        }
        $data   = $request->toArray();
        $data   = $this->NullToArray($data); 
        if($validator->fails()){
            return $this->sendResponse(400,$validator->messages()->first(),$data);
        }
        try{
            $res   =  $this->user->SocialLog($request->all());
            if($res['status']){
                $userData   =  $this->user::find($res['data']->id);
                $userData->token = $userData->createToken('fitness-app')->accessToken;
                $data  = $userData->toArray();
                $data   = $this->NullToArray($data); 
                return $this->sendResponse(200,$res['msg'],$data);
            }
            else
            return $this->sendResponse(500,$res['msg'], $data); 
        }catch(\Throwable $th){
            dd($th);
           return $this->sendResponse(500,'Something went wrong',$th);
        }  
    }


    public function goalList(request $request){
        try{
            $weight   =  $this->goal->select('id','name','type','created_at','updated_at')->where('type',1)->get();
            $routine   =  $this->goal->select('id','name','type','created_at','updated_at')->where('type',2)->get();
            $habbit   =  $this->goal->select('id','name','type','created_at','updated_at')->where('type',3)->get();
            
           $listing =  array('weight'=>$weight,'routine'=>$routine,'habbit'=>$habbit);
           $data   = $this->NullToArray($listing); 
        
            if($data)
            return $this->sendResponse(200,'List of goals',$data);
            else
            return $this->sendResponse(500,'Something went wrong', '');  
            
          }catch(\Throwable $th){
            return $this->sendResponse(500,'Something went wrong', $th);
        }
    }


    public function UpdatePhoto(request $request){
       
        $validator         =     Validator::make($request->all(), [
           'image'         =>    'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        ]);
        if($validator->fails()){  
            return $this->sendResponse(400,$validator->messages()->first(),$this->NullToArray($request->all()));
        }
        try{
            $obj      =   auth()->guard("api")->user();
            $path = public_path().'/users/' . $obj->id;
            if (!file_exists($path)) {
                File::makeDirectory($path, $mode = 0777, true, true);
            }else{
                unlink($path.'/'.$obj->profile_img);
            }
               if ($request->hasFile('image')) {
                $image = $request->file('image');
                $name = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = $path;
                $image->move($destinationPath, $name);
                $obj->profile_img   =    $name;
                $obj->save();
            }
            $data = $obj->toArray();
            $data = $this->NullToArray($data);            
            return $this->sendResponse(200,'User Profile updated successfully',$data);   
        }catch(\Throwable $th){
            return $this->sendResponse(500,'Something went wrong',$th);
        }
    }


}
