<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use Validator;
use App\Models\Membership;


class MembershipController extends BaseController
{
    
    public function __construct(Membership $mmbrsh)
    {
        $this->membership    =   $mmbrsh;
    }



    public function add(request $request)
    { 
        
        $rules = [
            'name'           => 'required',
            'price'          => 'required|numeric|between:0,99999.99',
            'features'       => 'required',
        ];
    
        $customMessages = [
            'required'     => 'The :attribute field can not be blank.',
            'numeric'      => 'The :attribute must be a number.',
            // 'min'          => [
            //     'numeric' => 'The :attribute must be at least :min.',
            //     'string' => 'The :attribute must be at least :min characters.',
            //     'array' => 'The :attribute must have at least :min items.',
            // ]
        ];

        $validator      =    Validator::make($request->all(),$rules,$customMessages);
    
      if($validator->fails())
      {
        return $this->sendResponse(404,$validator->messages()->first(),$request->all());

      }
      
      try{

        $res   =   $this->membership->add($request->all());
        if($res['status'])
          return $this->sendResponse(200,'membership added successfully',$request->all());
        else
        return $this->sendResponse(500,'Something went wrong',$request->all());


      }catch(\Throwable $th){
        return $this->sendResponse(500,'Something went wrong',$th);
      }

    }



    public function edit(request $request, $id)
    {  
        $rules  = [
         'name'           =>   'required',
         'price'          =>   'required|numeric|between:0,99999.99',
         'features'       =>   'required', 
        ];
    

        $customMessages =[
            'required'  => 'The :attribute field can not be blank',
            'numeric'   => 'The :attribute must be a number'
        ];


        $validator    =  Validator::make($request->all(),$rules,$customMessages);
        

        if($validator->fails())
        {
            return $this->sendResponse(404,$validator->messages()->first(),$request->all);
        }


        try{

            $res  = $this->membership->updateMem($request->all(), $id);
            if($res['status'])
             return $this->sendResponse(200,'membership updated successfully',$request->all());
            else  
            return $this->sendResponse(500,'Something went wrong',$request->all());


        }catch(\Throwable $th){
        return $this->sendResponse(500,'Something went wrong',$th);
      }
    }


    public function destroy($id)
    {  
     try{
          
        $obj   = $this->membership::find($id);
        if($obj)
        {
         $obj->destroy($id);
         return $this->sendResponse(200,'Membership deleted successfully',$id);    
        }else{
          return $this->sendResponse(404,'Id does not exist in our record',$id);    
        }

       }catch(\Throwable $Th)
       {
         return $this->sendResponse(500,'Something went wrong',$th);
       }
    }


    public function allMembership()
    {
        try{
 
            $obj    = $this->membership::all(); 
            return $this->sendResponse(200,'Listing of all membnership',$obj); 
        
           }catch(\Throwable $th)
           {
            return $this->sendResponse(500,'Something went wrong',$th); 
           }
    }

    public function viewMembership($id)
    {
        try{
 
            $obj    = $this->membership::find($id); 
            return $this->sendResponse(200,'Membnership detail',$obj); 
        
           }catch(\Throwable $th)
           {
            return $this->sendResponse(500,'Something went wrong',$th); 
           }
    }
}
