<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Exercise;
use App\Http\Controllers\API\BaseController;
use App\Models\SubExercise;

class ExerciseController extends BaseController
{
 
    public function __construct(Exercise $exercise, SubExercise $subexercise)
    {
        $this->exercise        =   $exercise;
        $this->subexercise     =   $subexercise; 
    }

    public function index()
    {
         try{
           $list      =  $this->exercise::with('MultiSubExercise')->select('id','name','description')->get();
           return $this->sendResponse(200,'List of exercise',$list); 
              
         }catch(\Throwable $th)
         {
            return $this->sendResponse(500,'Something went wrong',$th);
         }
    }




}
