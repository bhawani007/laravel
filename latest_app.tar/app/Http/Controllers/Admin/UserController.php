<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\ViewVideo;
use App\Models\SubExercise;
use Validator,Auth,Mail,Carbon\Carbon;

class UserController extends Controller
{
    public function __construct(User $user, ViewVideo $viewvideo, SubExercise $subexercise)
    {                  
        $this->user          =     $user;   
        $this->viewVideo     =     $viewvideo;   
        $this->subExercise   =     $subexercise;   
    }


    public function index(request $request)
    {
       
       if(!empty($request->all()))
       {
            $query  =  $this->user;

         if($request->startdate && $request->enddate)
         {
            $from  =  Carbon::parse($request->startdate)
                  ->startOfDay()        // 2018-09-29 00:00:00.000000
                  ->toDateTimeString(); // 2018-09-29 00:00:00

             $to   =  Carbon::parse($request->enddate)
                  ->endOfDay()          // 2018-09-29 23:59:59.000000
                  ->toDateTimeString(); // 2018-09-29 23:59:59

            $query =  $query->whereBetween('created_at', [$from, $to]);
         }

          $userlist = $query->role('user')->orderBy('id', 'DESC')->get();

       }
       else
       {
        $userlist = $this->user::role('user')->orderBy('id', 'DESC')->get();
       }

       return view('admin.user.index',compact('userlist'));
    }


    public function create()
    {
      return view('admin.user.add');
    }


    public function store(request $request)
    {

      $validator = Validator::make($request->all(),
      [
        'name'       => 'required|min:3|max:255',
        'email'      => 'required|email|unique:users,email',
        'dob'        => 'required',
        'gender'     => 'required',
        //'password'   => 'required|same:confirm_password|min:8' 

      ]);

      if($validator->fails())
      {
        return back()->withErrors($validator)->withInput();
      }

      try{
        
        $res  =  $this->user->add($request->all());
        if($res['status'])
        {
          $user   =  array('name' => $request->name,'email' => $request->email,'password'=>$res['password']);
          Mail::send('emails.welcome', ['user' => $user], function ($m) use ($user) {
            $m->from('hello@app.com', 'Fitness App');
  
            $m->to($user['email'], $user['name'])->subject('Welcome Email');
          });
          return redirect()->route('user.index')->with('success','User Added successfully');
        }
        else
        return back()->with('error','Something went wrong');

      }catch(\Throwable $th){
        dd($th);
       return back()->with('error','Something went wrong');
      }

    }


    public function edit($id)
    {  
       $info = $this->user::find($id);
       return view('admin.user.edit')->with('info', $info);;
    }

    public function update(request $request, $id)
    {
         $validator = Validator::make($request->all(), [
          'name'       => 'required|max:255',
          'email'      => 'required|email|unique:users,email,'.$id,
         ]);

         if($validator->fails())
         {
           return back()->withErrors($validator)->withInput();
         }

         try{

          $res = $this->user->updateUser($request->all(), $id);
          if($res['status'])
          return redirect()->route('user.index')->with('success','User updated successfully');
          else
          return back()->wtih('error','Something went wrong');

         }catch(\Throwable $th){
           return back()->with('error','Something went wrong'); 
         }

    }

    public function delete($id)
    {
      $res = $this->user::destroy($id);
      if($res)
      return redirect()->route('user.index')->with('success','User deleted successfully');
      else
      return back()->wtih('error','Something went wrong');
    }


    public function show($id)
    { 
      $info           =     $this->user::find($id);
      $allvideos      =     $this->viewVideo::
      join("sub_exercises", "view_videos.video_id", '=', "sub_exercises.id")
      ->where("view_videos.user_id",$id)->get();
      return view('admin.user.view')->with(compact('info','allvideos'));
    }

    public function changePassword(request $request, $id)
    {

      $validator    = Validator::make($request->all(), [
        'password'  => 'required|same:confirm_password|min:8',
      ]);

      if($validator->fails())
      {
        return back()->withErrors($validator)->withInput();
      }

      try{
        
       $res =  $this->user->changePass($request->all(), $id);
       if($res['status'])
       {
        Mail::send('emails.change-password', ['user' => $res], function ($m) use ($res) {
          $m->from('hello@app.com', 'Fitness App');

          $m->to($res['email'])->subject('Change Password');
        }); 
        return redirect()->route('user.index')->with('success','Password changed successfully');
       }
       else
       return back()->with('error','Something went wrong');  

      }catch(\Thowable $th){
        return back()->with('error','Something went wrong');
      }

    }
    
    
    public function deleteVideo($userId=0, $videoId=0)
    {
       $authLogin  = Auth::user()->id;
       if($authLogin)
       {
        $this->viewVideo::where('user_id',$userId)->where('video_id',$videoId)->delete();  
        return back()->with('success','View video deleted successfully'); 
       }else
       {
         return back()->with('error','Something went wrong');
       }       
    }
}
