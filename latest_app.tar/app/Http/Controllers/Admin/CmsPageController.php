<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CmsPage;
use Validator;

class CmsPageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {  
        $info = CmsPage::all();
        return view('admin.cmspages.index',['info' => $info]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      return view('admin.cmspages.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $validator   = Validator::make($request->all(), 
        [
          'title'        => 'required|max:255',
          'type'         => 'required',
          'description'  => 'required'
        ]);


        if($validator->fails())
        {
            return back()->withErrors($validator)->withInput();
        }

        try{

            $obj = new CmsPage;
            $res = $obj->add($request->all());
            if($res['status'])
            return redirect()->route('cms-pages.index')->with('success','Page added successfully');
            else
            return redirect()->route('cms-pages.index')->with('error','Something went wrong');

           }catch(\Throwable $th){
            return back()->with('error','Something went wrong');

        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $info  = CmsPage::find($id);
        return view('admin.cmspages.view')->with('info', $info);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $info = CmsPage::find($id);
        return view('admin.cmspages.edit',compact('info'));
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator   = Validator::make($request->all(), [
            'title'        => 'required|max:255',
            'type'         => 'required',
            'description'  => 'required'
        ]);

        if($validator->fails()){

           return back()->withErrors($validator)->withInput();
        }

        try{

            $obj = new CmsPage(); 
            $res = $obj->updatepage($request->all(), $id);
            if($res['status'])
            return redirect()->route('cms-pages.index')->with('success','Page added successfully');
            else
            return redirect()->route('cms-pages.index')->with('error','Something went wrong');

        }catch(\Throwable $th){
          return back()->with('error', 'Something went wrong');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        try{

            $obj = CmsPage::find($id);
            $obj->destroy($id);
            return redirect()->route('cms-pages.index')->with('success', 'Page deleted successfully');
        
        }catch(\throwable $th){
            return redirect()->route('cms-pages.index')->with('error', 'Something went wrong');
        }
    }

}
