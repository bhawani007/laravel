<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Membership;
use Validator;

class MembershipController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    
    public function __construct(Membership $membership)
    {
       $this->mem = $membership;
    } 


    public function index()
    {
        $info = $this->mem::all();
        return view('admin.memberships.index',compact('info')); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.memberships.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $validator = Validator::make($request->all(), [
         'name'          => 'required',
         'price'         => 'required|numeric|between:0,99999.99',
         'features'      => 'required' 
       ]);

       if($validator->fails())
       {
           return back()->withErrors($validator)->withInput();
       }

       try{
       
        $res = $this->mem->add($request->all());
        if($res['status'])
        return redirect()->route('membership.index')->with('success','Membership added successfully');
        else
        return redirect()->route('membership.index')->with('erros','Something went wrong');
       }catch(\Throwable $th){
           return redirect()->route('membership.index')->with('erros','Something went wrong');
       }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $info    = $this->mem::find($id);
        return view('admin.memberships.view',['info' => $info]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $info = $this->mem::find($id);
        return view('admin.memberships.edit', ['info' => $info]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator        =   Validator::make($request->all(), 
        [
           'name'        =>  'required',
           'price'       =>  'required|numeric|between:0,99999.99',
           'features'    =>  'required'    
        ]);

        if($validator->fails())
        {
            return back()->withErrors($validator)->withInput();
        }

        try{

            $res = $this->mem->updateMem($request->all(), $id);
            if($res['status'])
            return redirect()->route('membership.index')->with('success','Membership added successfully');
            else
            return redirect()->route('membership.index')->with('erros','Something went wrong');

        }catch(\Throwable $th){
            return redirect()->route('membership.index')->with('erros','Something went wrong');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try{

            $obj = $this->mem::find($id);
            $obj->destroy($id);
            return back()->with('success','Membership deleted successfully'); 

        }catch(\Throwable $th){
            return redirect()->route('membership.index')->with('error','Something went wrong');  
        }


    }
}
