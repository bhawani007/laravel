<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SystemSetting;
use Validator;

class SystemSettingController extends Controller
{

	public function __construct(SystemSetting $systemsett)
	{
         $this->systemsetting = $systemsett;
  }
  
  public function index()
  {
    $info = $this->systemsetting::all();
    return view('admin.systemsetting',['info' => $info]);
  }

  public function store(request $request)
  {
        $input = $request->all();
        $cusarr =[];
        foreach($input as $key => $val)
        { 
          if($key == "_token")
          {
           continue;
          }
          $cusarr[$key]  = $val;
        }


        $attributeNames = array(
          'cusd-1' => 'Mobile',
        );

        $validator   = Validator::make($cusarr, 
        [
          'cusd-1'   => 'required|numeric'
        ]);

        $validator->setAttributeNames($attributeNames);

        if($validator->fails())
        {
            return back()->withErrors($validator)->withInput();
        }
      
  
        try{

          foreach($cusarr as $key => $val)
          {  
            $dkey =  explode("-",$key);
            
            $obj         = $this->systemsetting::find($dkey[1]);
            $obj->value  = $val;
            $obj->save();
          }

         return redirect()->route('system.setting')->with('success','System setting updated successfully');
       }catch(\Thowable $th){
         return back()->with('error','Something went wrong');
       }
  }
}
