<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CmsPage extends Model
{
    use HasFactory;

    public function add(array $data)
    {
        try{

         $obj                   =    new CmsPage();
         $obj->title            =    $data['title'];
         $obj->type             =    $data['type'];
         $obj->description      =    $data['description'];
         $obj->save();
         $lastId = $obj->id;
         return array('status' => 1,'lastId' => $lastId);
         
        }catch(\Thowable $th){
         return array('status' => 0);
        } 
    }


    public function updatepage(array $data, $id)
    {
        try{

            $obj                   =    CmsPage::find($id);
            $obj->title            =    $data['title'];
            $obj->type             =    $data['type'];
            $obj->description      =    $data['description'];
            $obj->save();
            $lastId = $obj->id;
            return array('status' => 1,'lastId' => $lastId);

        }catch(\Throwable $th){
            return array('status' => 0);
        }
    }
}
