<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Goal;

class UserProfile extends Model
{
    use HasFactory;

    public function WeightGoal()
    {
       return $this->belongsTo(Goal::class,'weight_goal_id','id');
    }


    public function ExerciseRoutine()
    {
       return $this->belongsTo(Goal::class,'exercise_routine_id','id');
    }

    public function Foodhabit()
    {
       return $this->belongsTo(Goal::class,'food_habit_id','id');
    }

}
