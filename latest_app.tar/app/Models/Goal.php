<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Illuminate\Database\Eloquent\Model;
use App\Models\UserProfile;
use App\Models\User;





class Goal extends Model
{
    use HasFactory;
    use HasSlug;


    /**
     * Get the options for generating the slug.
     */
    public function getSlugOptions() : SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('name')
            ->saveSlugsTo('slug');
    }


    public function add($data)
    {
        try{
           
           $obj                =  new Goal();  
           $obj->name          =  $data['name'];  
           $obj->type          =  $data['type'];  
           //$obj->features      =  $data['features']; 
           $obj->save(); 
           return array('status' => 1);
        
        }catch(\Throwable $th){
          return array('status' => 0);
        }
    }

    public function updateGoal($data, $goalId)
    {
        try{
            $obj                      =    Goal::find($goalId);
            $obj->name                =    $data['name'];
            $obj->type                =    $data['type'];
            $obj->save();
            $ProId = $obj->id;
            return array('status'=>1);
    
          }catch(\Throwable $th){  
              return array('status'=>0); }    

    }


}
