<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\user;

class Notification extends Model
{
    use HasFactory;

    protected $guarded = ['id'];  


    public function senderDetail()
    {
        return $this->belongsTo(user::class,'sender_id');
    }

    public function receiverDetail()
    {
        return $this->belongsTo(user::class,'receiver_id');
    }
}
