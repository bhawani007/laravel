<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Membership extends Model
{
    use HasFactory;

    public function add($data)
    {
        try{
           
           $obj                =  new Membership();  
           $obj->name          =  $data['name'];  
           $obj->price         =  $data['price'];  
           $obj->features      =  $data['features']; 
           $obj->save(); 
           return array('status' => 1);
        
        }catch(\Throwable $th){
          return array('status' => 0);
        }
    }


    public function updateMem($data, $id)
    {
        try{
           
           $obj                =  Membership::find($id);  
           $obj->name          =  $data['name'];  
           $obj->price         =  $data['price'];  
           $obj->features      =  $data['features']; 
           $obj->save(); 
           return array('status' => 1);
        
        }catch(\Throwable $th){
          return array('status' => 0);
        }
    }


    
}
