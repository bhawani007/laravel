<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Exercise;

class SubExercise extends Model
{
    use HasFactory;

    protected $visible = ['id', 'name', 'video'];

    public function add($data)
    {

            try{  

                $exercise_id    =   $data['exercise_id'];
                $name           =   $data['name'];
                $videos         =   $data['videos'];
                $description    =   $data['description'];
                

                foreach($name as $key =>$val)
                {

                    $file_ex         =  $videos[$key]->getClientOriginalExtension();
                    $name            =  time().''.rand(11111, 99999) . '.' . $file_ex;
                    $destinationPath =  public_path('/subexercise');
                    $videos[$key]->move($destinationPath,$name);
                
                    $obj                  =  new SubExercise();
                    $obj->exercise_id     =  $exercise_id;   
                    $obj->name            =  $val;   
                    $obj->description     =  $description[$key];   
                    $obj->video           =  $name;   
                    $obj->save();

                }  
                return array('status' => 1);   
            }catch(\Throwable $th){
                return array('status' => 0);  
            } 

    }


    public function exercise()
    {
        return $this->belongsTo(Exercise::class,'exercise_id','id');
    }


    public function updateData($data)
    {    
        try{

            $exercise_id    =   $data['exercise_id'];
            $name           =   $data['name'];
            $videos         =   $data['videos'];
            $description    =   $data['description'];
            $ids            =   $data['ids'];

            foreach($name as $key =>$val)
            {
                $id              =  $ids[$key]; 

                if($id)
                {
                    $obj         =  SubExercise::find($id);
                }
                else
                {
                    $obj         =  new SubExercise();
                } 

                if(gettype($videos[$key]) == "object")
                {
                    $file_ex         =  $videos[$key]->getClientOriginalExtension();
                    $name            =  time().''.rand(11111, 99999) . '.' . $file_ex;
                    $destinationPath =  public_path('/subexercise');
                    $videos[$key]->move($destinationPath,$name);
                }
                else
                {
                    $name            =  $videos[$key];
                }


                $obj->exercise_id     =  $exercise_id;   
                $obj->name            =  $val;   
                $obj->description     =  $description[$key];   
                $obj->video           =  $name;   
                $obj->save();

            } 
            return array('status' => 1); 
        }catch(\Throwable $th)
        {
                return array('status' => 0);  
        } 
    }
}
