<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\SubExercise;

class Exercise extends Model
{
    use HasFactory;

    public function add($data)
    {
        //    if(!empty($data['video']))
        //    { 
        //     $video       =     $data['video'];
        //     $name = time().'.'.$video->getClientOriginalExtension();
        //     $destinationPath = public_path('/exercise');
        //     $video->move($destinationPath, $name);
        //    }else{
        //       return array('status' => 0, 'error' => 'video is required'); 
        //    } 
                
        try{

            $obj                           =    new Exercise();
           // $obj->video                  =    $name; 
            $obj->name                     =    $data['name']; 
            $obj->description              =    $data['description'];
            $obj->save(); 
            return array('status' => 1);
        
        }catch(\Throwable $th)
        {   
            return array('status' => 0);
        }

    }


    public function updateExer($data, $id)
    {
            $obj             =  Exercise::find($id);
            // if(!empty($data['video']))
            // {  
            //     $video           =  $data['video'];
            //     $name            =  time().'.'.$video->getClientOriginalExtension();
            //     $destinationPath =  public_path('/exercise');
            //     $video->move($destinationPath, $name);
                
            //     $obj->video      =   $name;    
            // }
       
            try{

                $obj->name           =    $data['name'];
                $obj->description    =    $data['description'];
                $obj->save();
                return array('status' =>1); 

            }catch(\Throwable $th){
                return array('status'=>0);
            }
    }


    public function MultiSubExercise()
    {
        return $this->hasMany(SubExercise::class, 'exercise_id');
    }

}
