@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">CMS Pages</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{route('cms-pages.index')}}">CMS Pages</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Add</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12 mb-4">
        <div class="fade-in">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header"><strong>CMS Pages</strong></div>

                        <div class="card-body">
                         <form action="{{ route('cms-pages.store') }}" method="POST" enctype="multipart/form-data">
                           @csrf
                             <div class="row">
                                <div class="col-md-12">
                                        <div class="form-group">
                                        <label for="name">Title<span style="color:red">*</span></label>
                                        <input type="text" name="title" value="{{ old('name') }}" class="form-control">
                                        </div>
                                </div>
                                <div class="col-md-12">   
                                    <div class="form-group">
                                        <label for="type">Type<span style="color:red">*</span></label>
                                        <select name="type" class="form-control">
                                            <option value="About-Us">About us</option>
                                            <option value="Testimonial">Testimonial</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="lique-cls">
                                        <div class="form-group">
                                            <label for="dob">Description</label>
                                            <textarea name="description" class="form-control">{{ old('description') }}</textarea>
                                        </div>
                                    </div>
                                </div>
                             </div>
                                <button type="reset" class="btn btn-sm btn-danger">Reset</button> 
                                <button class="btn btn-sm btn-primary">Submit</button> 
                           </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('admin.includes.footer')
</div>

@endsection

@section('custom_js')
<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>

<script type="text/javascript">
     $( function() {
        CKEDITOR.replace( 'description' );
  });
</script>

@endsection