<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, minimum-scale=1, user-scalable=0" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Fitness App</title>
    <!-- <link rel="icon" type="image/png" href="images/favicon-32x32.png" sizes="32x32" /> -->
    @include('admin.includes.css')
</head>

<body>
<div class="navbar navbar-expand flex-column flex-md-row align-items-center navbar-custom">
    <div class="container-fluid">
        <!-- <a href="#" class="navbar-brand mr-0 mr-md-2 logo">
            <img src="images/logo.svg" alt="Logo">
        </a> -->
        <button type="button" class="navigation-btn"><i class="fal fa-bars"></i></button>
        <ul class="navbar-nav flex-row ml-auto d-flex align-items-center list-unstyled topnav-menu mb-0">
           
            
            <li class="dropdown user-link">
                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button"
                    aria-haspopup="false" aria-expanded="false">
                    <i class="far fa-cog"></i>
                    <span class="noti-icon-badge"></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right dropdown-lg">
                    <a href="{{ route('profile') }}" class="dropdown-item"> <i class="fal fa-user"></i> My Profile</a>
                    <div class="dropdown-divider"></div>
                    <a href="{{ route('logout') }}" class="dropdown-item"><i class="fal fa-sign-out"></i> Logout</a>
                </div>
            </li>
        </ul>
    </div>
</div>

@include('admin.includes.sidebar')

@yield('content')
@yield('custom_css')
@include('admin.includes.js')
@include('admin.includes.toast')
@yield('custom_js')

</body>

</html>