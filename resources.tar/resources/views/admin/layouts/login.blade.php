<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, minimum-scale=1, user-scalable=0" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Fitness App</title>
    <!-- <link rel="icon" type="image/png" href="images/favicon-32x32.png" sizes="32x32" /> -->
  <!-- start css -->
   @include('admin.includes.css')
   @yield('admin_custom_css')
 <!-- end css -->   
</head>

<body>
<!-- start middle section -->
@yield('content')
<!-- end middle section -->
</body>

<!-- start js-->
 @include('admin.includes.js')
 @include('admin.includes.toast')
 @yield('admin_custom_js')
<!-- end js-->
</html>