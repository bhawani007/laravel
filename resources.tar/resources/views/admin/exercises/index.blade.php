@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Exercise</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Exercise</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="row">
           
            <div class="col-sm-12 mb-4">
                <a href="{{route('exercises.create')}}"><span style="margin-left: 10px" class="badge badge-primary float-right">Add</span></a>
            </div> 
            <div class="col-sm-12 mb-4">
                <div class="box bg-white">
                    <div class="box-row">
                        <div class="box-content">  
                            <table id="dataTable" class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col" class="sr-no">#</th>
                                        <!-- <th scope="col">Video</th> -->
                                        <th scope="col">Name</th>
                                        <th scope="col">Description</th>
                                        <th scope="col" class="action">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                               
                                @foreach($info as $key => $val)
                                
                                    <tr>
                                        <td scope="row" class="sr-no">{{ $key+1 }}</td>
                                        <!-- <td>
                    
                                        <video width="320" height="240" controls>
                                            <source src="asset('exercise/'.$val->video)" type="video/mp4">
                                            <source src="asset('exercise/'.$val->video)" type="video/ogg">
                                        </video>
                                        
                                        </td> -->
                                        <td>{{  @$val->name }}</td>
                                        <td>{!! @$val->description !!}</td>
                                        <td class="action">

                                        <a href="{{ route('exercises.show',$val->id) }}" title="View" class="icon-btn preview text-center"><i class="fal fa-eye"></i></a>
                                        <a href="{{ route('exercises.edit',$val->id) }}" title="Edit" class="icon-btn edit text-center"><i class="fal fa-edit"></i></a>
                                        <button title="Delete" onclick="GetAction('{{ route('exercises.delete',$val->id) }}')"  type="button" class="icon-btn delete"><i class="fal fa-times"></i></button>
                                       </td>
                                    </tr>

                               @endforeach   
                              
                               </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            @include('admin.includes.footer')
        </div>
    </div>
</div>

@endsection

@section('custom_js')
<style>
    .eye-icons {
    color: #fff;
    }
</style>
@endsection

@section('custom_js')
<script type="text/javascript">

    $(function() {
        $('#dataTable').DataTable();
        $( "#dataTable" ).wrap( '<div class="table-responsive"></div>' );
    }) 

</script>
@endsection
