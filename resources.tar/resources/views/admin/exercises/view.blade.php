@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Exercise Detail</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{route('exercises.index')}}">Exercise</a></li>
                        <li class="breadcrumb-item active" aria-current="page">View</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="row"> 
                
            <div class="col-sm-12 mb-4">
                <div class="box bg-white">
                    <div class="box-row">
                        <div class="box-content">  
                            <table id="dataTable" class="table table-bordered table-hover">
                               
                                 <tr>
                                 <th scope="col" class="sr-no">Id</th> 
                                 <td scope="row" class="sr-no">{{ $execisedetail->id }} </td>
                                 </tr>
                                 
                                 <!-- <tr>
                                 <th scope="col">Video</th> 
                                 <td>                                 
                                    <video width="320" height="240" controls>
                                        <source src="asset('exercise/'.$info->video)" type="video/mp4">
                                        <source src="asset('exercise/'.$info->video)" type="video/ogg">
                                    </video>
                                  </td>
                                 </tr> -->


                                 <tr>
                                 <th scope="col">Name</th> 
                                 <td>{{ $execisedetail->name }} </td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Description</th> 
                                 <td>{!! $execisedetail->description !!} </td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Created at</th>
                                 <td>{{ $execisedetail->created_at }}</td>
                                 </tr>
                   
                                 <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                    
                </div>
                
            </div>
             <div class="col-md-12">
                 <div class="btn-block">
                    <button style="" class="btn btn-sm btn-primary" type="submit" id="append" name="append">
                    Add</button>
                </div>
            </div>
            <div class="col-sm-12 mb-4">
                <div class="box bg-white">
                    <div class="box-row">
                    <form action="javascript:void(0)" method="POST" enctype="multipart/form-data" id="formId">
                           @csrf
                        <div class="row">
                            @foreach(@$info as $key => $val) 
                                <div class="col-md-12">
                                          <div class="inc">
                                                <div class="controls row">
                                                    <div class="form-group col-md-4">
                                                        <label for="name">Name<span style="color:red">*</span></label> 
                                                        <input type="text" class="form-control" value="{{ @$val['name'] }}" name="name[]"/> 
                                                        <input type="hidden" id="tt_fields" value="{{ old('tal_f') }}" class="form-control" name="tal_f" /> 
                                                        <input type="hidden" id="ex_id" value="{{ $execisedetail->id }}"  name="exercise_id" /> 
                                                        <input type="hidden"  value="{{ @$info[$key]->id }}"  name="ids[]" /> 
                                                    </div>

                                                    <div class="form-group col-md-3">
                                                      <label for="video">Video<span style="color:red">*</span></label> 
                                                      <input type="file" class="form-control" name="videos[]" value="{{ @$val['video'] }}" />
                                                      <input type="hidden"  accept="video/* class="form-control" name="videos[]" value="{{ @$val['video'] }}" />
                                                        <video width="160" height="80" controls>
                                                        <source src="{{ asset('subexercise/'.@$val['video']) }}" type="video/mp4">
                                                        src="{{asset('video/abc/jp.mp4')}}"
                                                        <source src="{{ asset('public/subexercise/'.@$val['video']) }}" type="video/ogg">
                                                        </video>
                                                    </div>    

                                                    <div class="form-group col-md-4">
                                                      <label for="description">Description<span style="color:red">*</span></label> 
                                                      <textarea class="form-control" name="description[]">{{ @$val['description'] }}</textarea>
                                                    </div>  
                                                    <div class="col-md-1">
                                                    <!-- <button onclick="GetAction('{{ route('sub.exercises.delete',@$info[$key]->id) }}')"  type="button" class="remove_this btn btn-danger"><i class="fal fa-times"></i></button> -->
                                                    </div>  
                                                </div>
                                          </div>
                                </div>
                             @endforeach    
                             

                             @if(count(@$info) == 0)
                                <div class="col-md-12">
                                    <div class="inc"></div>
                                </div>   
                             @endif   

                             <input type="hidden" name="allcount" id="allcount" value="{{ count($info) }}">


                             </div>
                            <span id="button-div">
                                <button type="reset" class="btn btn-sm btn-danger">Reset</button> 
                                <button class="btn btn-sm btn-primary" id="send_data">Submit</button>
                            </span>                                
                    </form>
                    </div>
                   
                    
                </div>
                
            </div>
          
            @include('admin.includes.footer')
        </div>
    </div>
</div>




@endsection

@section('custom_css')
<style>
.nn{
    display:none !important;
}

.bck th, .bck td {
    width: 50%;
}

.fade-in .btn-block {
    display: block;
    width: 100%;
    text-align: right;
}
.remove_this.btn.btn-danger {
    margin-top:32px;
}
.main-content .btn-block {
    text-align: right;
    padding-bottom: 15px;
}
</style>

@endsection


@section('custom_js')
<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>

<script type="text/javascript">
      var total_f  = 0;
      $( function() {
       // CKEDITOR.replace( 'description' );
       var alcnt = $("#allcount").val();
       if(alcnt == 0)
       {
        $("#button-div").hide();
         $("div.box.bg-white").last().removeClass("box bg-white");
       }else{    
        $("#button-div").show();
       }
        

       
      $("#append").click( function(e) {
        ++total_f;  
        $("#tt_fields").val(total_f);
        $("#button-div").show();
        $("div.box-row").last().parent().addClass('box bg-white');
      e.preventDefault();
      $(".inc:last").after('<div class="controls row">\
         <div class="form-group col-md-4"> <label for="name">Name<span style="color:red">*</span></label><input type="hidden"  value="0"  name="ids[]" /> <input class="form-control" type="text" value="{{ old('".name."') }}" name="name[]">  <input type="hidden" id="ex_id" value="{{ $execisedetail->id }}"  name="exercise_id" /> </div>\
         <div class="form-group col-md-3"> <label for="video">Video<span style="color:red">*</span></label> <input class="form-control" type="file" value="" accept="video/*" name="videos[]"></div>\
         <div class="form-group col-md-4"> <label for="description">Description<span style="color:red">*</span></label> <textarea class="form-control" name="description[]"></textarea></div>\
         <div class="col-md-1 mb-4 text-right"><a href="#" class="remove_this btn btn-danger"><i class="fal fa-times"></i></a></div> \
      </div>');
      return false;
      });

      $(document).on('click', '.remove_this', function() {
        $(this).parent().parent().remove();
        if($('.remove_this').length == 0 && $("#allcount").val()==0){
            $("#button-div").hide();
            $("div.box.bg-white").last().removeClass("box bg-white");
        }
        return false;
      });


      $('#send_data').click(function(e){ 
        e.preventDefault();
        $("#pageloader").fadeIn();
        /*Ajax Request Header setup*/
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var formData  = new FormData($('#formId')[0]);
       
   
   /* Submit form data using ajax*/
   $.ajax({  
      url: "{{ route('sub-exercise.update') }}",
      method: 'post',
     // dataType: 'JSON',
      data: formData,
      cache:false,
      contentType: false,
      processData: false,
      success: function(response){
            $("#pageloader").fadeOut();
            var finallymsg ='';
            if(response.status=='success')
            {
                finallymsg = response.msg;
                 document.getElementById("formId").reset(); 
            }
            else
            {
                $.each(response.msg, function( key, value )
                 {
                    finallymsg += value+'<br>';
                });
            }
           
        
            (function () {
                Lobibox.notify(response.status, {
                    rounded: false,
                    delay: 4000,
                    delayIndicator: true,
                    msg: finallymsg
                });
            })();
        
            if(response.status=='success')
            {
                setTimeout(function(){
                  window.location.href = "{{ route('exercises.show',$execisedetail->id) }}"
                },3000); 
            }      
    
      }});
   });
  });

  $("#append").click(function() {
       $("html, body").animate({ scrollTop: $(document).height() }, "slow");
    });
</script>

@endsection
