@extends('admin.layouts.login')
@section('content')


<div class="login-page">
        <div class="fotgate-info">
            <div class="contentBox ">
                <!-- <div class="logo d-flex flex-wrap w-100">
                    <img src="images/logo.svg" alt="logo">
                </div> -->
                <h1>Welcome to Fitness App</h1>
                <p>Enter your email address.If email is found then we send a email into your email address.</p>
                <form class="mt-4" action="{{ route('forgot-password') }}" name="forgotpass" method="post">
                @csrf
                    <div class="form-group">
                        <label>Email Address</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fal fa-envelope"></i></span>
                            </div>
                            <input type="email" require name="email" id="email" value="{{ old('email') }}" class="form-control" placeholder="">
                        </div>
                    </div>
                  
                    <div class="form-group mb-0">
                        <button type="submit" class="btn btn-primary w-100">Submit</button>
                    </div>
                </form>
            </div>
            <!-- <div class="imgBox d-none d-md-block">
                <img src="{{ asset('images/cover.png') }}" alt="image">
            </div> -->
        </div>
    </div>
 @endsection   


@section('admin_custom_js')
<script type="text/javascript">
     $( function() {
        $("form[name='forgotpass']").validate({
            
            rules: {
                 email: {
                    required: true,
                    email: true
                },
            },
    
            // Make sure the form is submitted to the destination defined
            // in the "action" attribute of the form when valid
            submitHandler: function(form) {
            form.submit();
            $("#pageloader").fadeIn();
            }
            
        });

  });
</script>

@endsection     


@section('admin_custom_css')
<style>
.fotgate-info {
    width: 50%;
    background-color: #fff;
    padding: 30px;
    border-radius: 4px;
    border: 1px solid #ddd;
}
</style>


@endsection