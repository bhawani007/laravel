@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Users</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{route('user.index')}}">Users</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12 mb-4">
        <div class="fade-in">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header"><strong>Users</strong></div>

                        <div class="card-body">
                         <form action="{{ route('user.update',$info->id) }}" method="POST" enctype="multipart/form-data">
                           @csrf
                             <div class="row">
                             <div class="col-md-6">
                                    <div class="form-group">
                                       <label for="name">Name<span style="color:red">*</span></label>
                                       <input type="text" name="name" value="{{ @$info->name }}" class="form-control">
                                       <input type="hidden" name="role" value="user"> 
                                    </div>
                             </div>
                             <div class="col-md-6">   
                                    <div class="form-group">
                                        <label for="email">Email<span style="color:red">*</span></label>
                                        <input type="text" name="email" value="{{ @$info->email }}"  class="form-control">
                                    </div>
                            </div>

                              
                            <div class="col-md-6">
                                <div class="lique-cls">
                                    <div class="form-group">
                                        <label for="dob">DOB<span style="color:red">*</span></label>
                                        <input type="text" readonly id="datepicker" name="dob" value="{{ @$info->profile->dob }}"  class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="lique-cls">
                                    <div class="form-group">
                                        <label for="gender">Gender</label>
                                        <select name="gender" class="form-control">
                                            <option value="Male" {{@$info->profile->gender=="Male"?'selected':''}}>Male</option>
                                            <option value="Female" {{@$info->profile->gender=="Female"?'selected':''}}>Female</option>
                                            <option value="Other" {{@$info->profile->gender=="Other"?'selected':''}}>Other</option>
                                        </select>
                                    </div>  
                                </div>
                            </div>  
                                    

                            <!-- <div class="col-md-6">
                                <div class="form-group">
                                    <label for="height">Height</label> //$info->profile->height 
                                    <input type="text" name="height" value=""  class="form-control">
                                </div>
                            </div> -->


                            <!-- <div class="col-md-6">
                                <div class="form-group">
                                    <label for="weight">Weight (In KG)</label>//$info->profile->weight
                                    <input type="text" name="weight" value=""  class="form-control">
                                </div>
                            </div> -->
                         </div>
                                <button type="reset" class="btn btn-sm btn-danger">Reset</button> 
                                <button class="btn btn-sm btn-primary">Submit</button> 
                           </form>
                        </div>
                    </div>   
                </div>

                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header"><strong>Change Password</strong></div>

                        <div class="card-body">
                         <form action="{{ route('user.changepassword',$info->id) }}" method="POST" enctype="multipart/form-data">
                           @csrf
                             <div class="row">
                             <div class="col-md-12">
                                    <div class="form-group">
                                       <label for="name">Password</label>
                                       <input type="password" name="password"  class="form-control">
                                    </div>
                             </div>
                             <div class="col-md-12">   
                                    <div class="form-group">
                                        <label for="email">Confirm Password</label>
                                        <input type="password" name="confirm_password"  class="form-control">
                                    </div>
                                </div>

                         </div>
                                <button type="reset" class="btn btn-sm btn-danger">Reset</button> 
                                <button class="btn btn-sm btn-primary">Submit</button> 
                           </form>
                        </div>
                    </div>   
                </div>
            </div>
        </div>
    </div>

    @include('admin.includes.footer')
</div>

@endsection

@section('custom_js')

<script type="text/javascript">
     $( function() {
        $( "#datepicker" ).datepicker({
         changeMonth : true,
         changeYear  : true,
         dateFormat  : 'yy-mm-dd',
         yearRange   : "c-100:c+100",
         maxDate     : 'now'
        });
  });
</script>

@endsection