@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">User Detail</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{route('user.index')}}">Users</a></li>
                        <li class="breadcrumb-item active" aria-current="page">View</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="row"> 
            <div class="col-sm-12 mb-4">
                <div class="box bg-white">
                    <div class="box-row">
                        <div class="box-content">  
                            <table id="dataTable" class="table table-bordered table-hover">
                               
                                 <tr>
                                 <th scope="col" class="sr-no">Id</th> 
                                 <td scope="row" class="sr-no">{{ $info->id }} </td>
                                 </tr>
                                 
                                 <tr>
                                 <th scope="col">Name</th> 
                                 <td>{{ @$info->name }} </td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Email</th> 
                                 <td>{{ @$info->email }} </td>
                                 </tr>


                                 <tr>
                                 <th scope="col">DOB</th> 
                                 <td>{{ @$info->profile->dob }} </td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Gender</th> 
                                 <td>{{ @$info->profile->gender }} </td>
                                 </tr>


                                 <tr>
                                 <th scope="col">Height</th> 
                                 <td>{{ @$info->profile->height }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Weight</th> 
                                 <td>{{ @$info->profile->weight }}</td>
                                 </tr>


                                 <tr>
                                 <th scope="col">Activity Level</th> 
                                 <td>{{ @$info->profile->activity_level }}</td>
                                 </tr>


                                 <tr>
                                 <th scope="col">Weight Goal</th> 
                                 <td>{{ @$info->profile->WeightGoal->name }}</td>
                                 </tr>


                                 <tr>
                                 <th scope="col">Exercise Routine</th> 
                                 <td>{{ @$info->profile->ExerciseRoutine->name }}</td>
                                 </tr>


                                 <tr>
                                 <th scope="col">Food Habits</th> 
                                 <td>{{ @$info->profile->Foodhabit->name }}</td>
                                 </tr>


                                 <tr>
                                 <th scope="col">Min Calories Intake</th> 
                                 <td>{{ @$info->profile->calorie_min }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Max Calories Intake</th> 
                                 <td>{{ @$info->profile->calorie_max }}</td>
                                 </tr>



                                 <tr>
                                 <th scope="col">Created at</th>
                                 <td>{{ $info->created_at }}</td>
                                 </tr>
                   
                                 <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-12 mb-4">
             <h1 class="h3 m-0 food-intake-plan">Food Intake Plan</h1>
                <div class="box bg-white">
                    <div class="box-row">
                        <div class="box-content">  
                            <table id="dataTable" class="table table-bordered table-hover">
                               
                                 <tr>
                                 <th scope="col" class="sr-no">Breakfast</th> 
                                 <td scope="row" class="sr-no"></td>
                                 </tr>
                                 
                                 <tr>
                                 <th scope="col">Lunch</th> 
                                 <td></td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Dinner</th> 
                                 <td>  </td>
                                 </tr>


                                 <tr>
                                 <th scope="col">Shankes</th> 
                                 <td>  </td>
                                 </tr>


                   
                                 <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-12 mb-4">
             <h1 class="h3 m-0 view-video">List of View Video</h1>
                <div class="box bg-white">
                    <div class="box-row">
                        <div class="box-content">  
                            <table id="dataTable" class="table table-bordered table-hover">
                               
                                 <tr>
                                        <th scope="col" class="sr-no">S.No</th> 
                                        <th scope="col">Name</th> 
                                        <th scope="col">Video</th> 
                                        <th scope="col">Action</th> 
                                 </tr>


                                 @foreach($allvideos as $key =>$val)

                                    <tr>
                                        <td>{{ $key+1 }}</td> 
                                        <td><a href="{{ route('sub-exercise.show',$val->id) }}">{{ $val->name }}</a></td> 
                                        <td>
                                            <video width="240" height="160" controls>
                                                    <source src="{{ asset('subexercise/'.$val->video) }}" type="video/mp4">
                                                    <source src="{{ asset('subexercise/'.$val->video) }}" type="video/ogg">
                                            </video>
                                        </td>
                                        <td class="action">  
                                        <button title="Delete" onclick="GetAction('{{ url('admin/user-view-video-delete',$val->user_id) }}/{{$val->video_id}}')"  type="button" class="icon-btn delete"><i class="fal fa-times"></i></button>
                                        </td> 
                                    </tr>

                                 @endforeach


                                 @if(count($allvideos) == 0)

                                    <tr>
                                        <td colspan="4"><strong>No video view yet</strong></td> 
                                    </tr>

                                 @endif
                                 
                
                                 <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            @include('admin.includes.footer')
        </div>
    </div>
</div>
@endsection

@section('custom_css')
<style>
.nn{
    display:none !important;
}

.bck th, .bck td {
    width: 50%;
}
.h3.m-0.food-intake-plan {
    padding-bottom: 15px;
}
.h3.m-0.view-video {
    padding-top:30px;
    padding-bottom:15px;
}
</style>

@endsection

@section('custom_js')
<script type="text/javascript">
   
</script>
@endsection
