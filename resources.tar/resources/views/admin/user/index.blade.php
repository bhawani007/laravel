@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Users</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Users</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="row">
        <div class="col-sm-12 mb-4">
                <form class="box bg-white" action="{{ route('user.index') }}" method="get">
                    <div class="box-title pb-0">
                        <h5>Filter</h5>
                    </div>
                    <div class="d-flex flex-wrap align-items-end py-4">
                        <div class="col-md-3">
                            <div class="form-group mb-0">
                                <label>Start Date</label>
                                <div class="input-group">
                                    <input type="text" readonly id="startdatepicker" name="startdate" value="{{ isset($_GET['startdate'])?$_GET['startdate']:'' }}"  class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group mb-0">
                                <label>End Date</label>
                                <div class="input-group">
                                    <input type="text" readonly id="enddatepicker" name="enddate" value="{{ isset($_GET['enddate'])?$_GET['enddate']:'' }}"  class="form-control">
                                </div>
                            </div>
                        </div>
                       
                        <div class="col-md-3 text-right">
                            <div class="form-group mb-0">
                                <button type="submit" class="btn btn-primary w-100">Search</button>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group mb-0">
                           <button class="btn btn-sm btn-danger" type="reset"> <a href="{{ route('user.index') }}">Reset</a></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-sm-12 mb-4">
                <a href="{{route('user.add')}}"><span style="margin-left: 10px" class="badge badge-primary float-right">Add</span></a>
            </div> 
            <div class="col-sm-12 mb-4">
                <div class="box bg-white">
                    <div class="box-row">
                        <div class="box-content">  
                            <table id="dataTable" class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col" class="sr-no">#</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email </th>
                                        <th scope="col">Created Date</th>
                                        <th scope="col" class="action">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                               
                                @foreach($userlist as $key => $val)
                                
                                    <tr>
                                        <td scope="row" class="sr-no">{{ $key+1 }}</td>
                                        <td>{{ $val->name }}</td>
                                        <td>{{ @$val->email }}</td>
                                        <td>{{ @$val->created_at }}</td>
                                        <td class="action">
                                           <a href="{{ route('user.view',$val->id) }}" title="View" class="icon-btn preview text-center"><i class="fal fa-eye"></i></a>
                                           <!-- <button type="button" title="View" class="icon-btn preview"><a href="{{ route('user.view',$val->id) }}"><i class="fal fa-eye"></i></a></button> -->
                                           <a href="{{ route('user.edit',$val->id) }}" title="Edit" class="icon-btn edit text-center"><i class="fal fa-edit"></i></a>
                                           <button title="Delete" onclick="GetAction('{{ route('user.delete',$val->id) }}')"  type="button" class="icon-btn delete"><i class="fal fa-times"></i></button>
                                        </td>
                                    </tr>

                               @endforeach   
                              
                               </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            @include('admin.includes.footer')
        </div>
    </div>
</div>

@endsection

@section('custom_css')
    <style>
        .btn.btn-sm.btn-danger {
            padding: 11px 15px;
        }
        .btn.btn-sm.btn-danger a {
            color: #fff;
        }
    </style>
@endsection

@section('custom_js')
<script type="text/javascript">
    $(function() {
       // $('#dataTable').DataTable();  
        $('#dataTable').DataTable( {
        "order": [[ 3, "desc" ]]
        } );
        console.log('---index page---');
      
        $( "#dataTable" ).wrap( '<div class="table-responsive"></div>' );
        $( "#startdatepicker" ).datepicker({
            changeMonth : true,
            changeYear  : true,
            dateFormat  : 'yy-mm-dd',
            yearRange   : "c-100:c+0",
            maxDate     : 'now',
            onSelect: function(selected) {
                $("#enddatepicker").datepicker("option","minDate", selected)
            }
        });

        


        $( "#enddatepicker" ).datepicker({
            changeMonth : true,
            changeYear  : true,
            dateFormat  : 'yy-mm-dd',
            yearRange   : "c-100:c+0",
            maxDate     : 'now',
            // onSelect: function(selected) {
            //    $("#startdatepicker").datepicker("option","maxDate", selected)
            // }
        });

    })


</script>
@endsection
