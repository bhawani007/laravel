@extends('admin.layouts.default')
@section('content')
<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Users</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{route('user.index')}}">Users</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Add</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12 mb-4">
        <div class="fade-in">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header"><strong>Users</strong></div>

                        <div class="card-body">
                         <form action="{{ route('user.store') }}" name="userform" method="POST" enctype="multipart/form-data">
                           @csrf
                             <div class="row">
                             <div class="col-md-6">
                                    <div class="form-group">
                                       <label for="name">Name<span style="color:red">*</span></label>
                                       <input type="text" id="name" name="name" value="{{ old('name') }}" class="form-control">
                                       <input type="hidden" name="role" value="user"> 
                                    </div>
                             </div>
                             <div class="col-md-6">   
                                    <div class="form-group">
                                        <label for="email">Email<span style="color:red">*</span></label>
                                        <input type="text" id="email"  name="email" value="{{ old('email') }}"  class="form-control">
                                    </div>
                                </div>

                              
                            <div class="col-md-6">
                                <div class="lique-cls">
                                    <div class="form-group">
                                        <label for="dob">DOB<span style="color:red">*</span></label>
                                        <input type="text"  readonly id="datepicker" name="dob" value="{{ old('dob') }}"  class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="lique-cls">
                                    <div class="form-group">
                                        <label for="gender">Gender</label>
                                        <select name="gender" class="form-control">
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>  
                                </div>
                            </div>  
                                    

                            <!-- <div class="col-md-6">
                                <div class="form-group">
                                    <label for="height">Height</label>
                                    <input type="text" name="height" value="{{ old('height') }}"  class="form-control">
                                </div>
                            </div>


                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="weight">Weight (In KG)</label>
                                    <input type="text" name="weight" value="{{ old('weight') }}"  class="form-control">
                                </div>
                            </div> -->

                                <!-- <div class="col-md-6">   
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" name="password"  class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-6">   
                                    <div class="form-group">
                                        <label for="cpassword">Confirm Password</label>
                                        <input type="password" name="confirm_password"  class="form-control">
                                    </div>
                                </div> -->

                             </div>
                                <button type="reset" class="btn btn-sm btn-danger">Reset</button> 
                                <button class="btn btn-sm btn-primary">Submit</button> 
                           </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('admin.includes.footer')
</div>

@endsection

@section('custom_css')

@endsection

@section('custom_js')
<script type="text/javascript">
     $( function() {
        $( "#datepicker" ).datepicker({
         changeMonth : true,
         changeYear  : true,
         dateFormat  : 'yy-mm-dd',
         yearRange   : "c-100:c+0",
         maxDate     : 'now'

        });


        $("form[name='userform']").validate({
            
            rules: {
                 name: "required",
                email: {
                    required: true,
                    email: true
                },
            },
            
            messages: {
                name: "Please enter name",
                email: "Please enter a valid email address"
            },
            // Make sure the form is submitted to the destination defined
            // in the "action" attribute of the form when valid
            submitHandler: function(form) {
            form.submit();
             $("#pageloader").fadeIn();
            }
            
        });

  });
</script>

@endsection