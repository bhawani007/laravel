@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">System Setting</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">System Setting</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="row"> 
            <div class="col-sm-12 mb-4">
                <div class="box bg-white">
                    <div class="box-row">
                        <div class="box-content">  
                            <table id="dataTable" class="table table-bordered table-hover">
                            <form action="{{ route('system.setting.store') }}" method="POST">
                            <button class="btn btn-sm btn-primary">Submit</button> 
                           @csrf
                                 <tr>
                                 <th scope="col" class="sr-no">Id</th>
                                    <td scope="row">Name</td>
                                    <th scope="col">Value</th>
                                 </tr>
                               
                               @foreach($info as $key =>$val)

                                 <tr>
                                    <td>{{ $val->id }}</td>
                                    <td>{{ $val->name }}</td>
                                    <td><input type="text" name="cusd-{{ $val->id }}" value="{{ $val->value }}" class="form-control"> </td>
                                 </tr>

                               @endforeach 
                             </form>  
                                 <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            @include('admin.includes.footer')
        </div>
    </div>
</div>
@endsection

@section('custom_css')
<style>
.nn{
    display:none !important;
}

.bck th, .bck td {
    width: 50%;
}
.box .box-row .box-content {
    width: 100%;
    text-align: right;
    padding-bottom: 15px;
}
.box .box-row .box-content .btn.btn-primary {
    margin-bottom: 15px;
}
.action .table td.action .icon-btn.preview a i {
    color:#fff !important;
}
</style>

@endsection

@section('custom_js')
<script type="text/javascript">
   
</script>
@endsection
