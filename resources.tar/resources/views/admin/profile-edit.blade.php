
@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Edit Profile</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('profile') }}">Profile</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="row">
            <div class="col-lg-12 col-md-4 mb-4">
                <form class="box bg-white" method="POST" action="{{ route('profile.update') }}" enctype="multipart/form-data">
                 @csrf
                    <div class="box-row flex-wrap">
                        <div class="profile-information mb-3">
                            <div class="user-icon">
                                <img src="{{ asset('images/'.$info->profile_img) }}" alt="img">
                                <div class="img-upload">
                                    <input type="file" name="pic" class="file" accept="image/*" id="profile-img">
                                    <label for="profile-img"><i class="fal fa-camera"></i></label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="form-group">
                                <label>Name</label>
                                <div class="input-group">
                                    <input type="text" name="name" class="form-control" placeholder="" value="{{ $info->name }}">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="form-group">
                                <label>Email</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="email"  value="{{ $info->email }}">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="form-group">
                                <label>Phone Number</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="phone" value="{{ $info->phone }}">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="form-group">
                                <label>Address</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="address" value="{{ $info->address }}">
                                </div>
                            </div>
                        </div>
                    
                        
                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <label>About</label>
                                <div class="input-group">
                                    <textarea class="form-control" name="about">{{ $info->about }}</textarea>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 mb-3 text-center">
                            <button type="reset" class="btn btn-light">Reset</button> 
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
            <!-- <div class="col-sm-12 copyright">
                <p>2015 - 2019 © demo theme by <a href="#">Arka Softwares</a></p>
            </div> -->
        </div>
    </div>
</div>

@endsection

