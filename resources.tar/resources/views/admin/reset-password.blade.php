@extends('admin.layouts.login')
@section('content')
<div class="login-page">
        <div class="fotgate-info">
            <div class="contentBox">
                <!-- <div class="logo d-flex flex-wrap w-100">
                    <img src="images/logo.svg" alt="logo">
                </div> -->
                <h1>Welcome to Fitness App</h1>
                <p>Enter your new password and confirm password</p>
                <form class="mt-4" action="{{ route('reset-password-data') }}" method="post">
                @csrf
                    <div class="form-group">
                        <label>New Password</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fal fa-envelope"></i></span>
                            </div>
                            <input type="password" name="password" class="form-control" placeholder="">
                            <input type="hidden" name="token" class="form-control" value={{ $token }}>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Confirm Password</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fal fa-lock"></i></span>
                                </div>
                                <input type="password" name="confirm_password"  class="form-control" placeholder="">
                               
                            </div>
                    </div>
                 
                    <div class="form-group mb-0">
                        <button type="submit" class="btn btn-primary w-100">Reset</button>
                    </div>
                </form>
            </div>
            <!-- <div class="imgBox d-none d-md-block">
                <img src="images/cover.png" alt="image">
            </div> -->
        </div>
    </div>
 @endsection   


@section('admin_custom_js')
       
@endsection     


@section('admin_custom_css')

<style>
    .fotgate-info {
        width: 50%;
        background-color: #fff;
        padding: 30px;
        border-radius: 4px;
        border: 1px solid #ddd;
    }
</style>

@endsection