@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Product Detail</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{route('product.index')}}">Products</a></li>
                        <li class="breadcrumb-item active" aria-current="page">View</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="row"> 
            <div class="col-sm-12 mb-4">
                <div class="box bg-white">
                    <div class="box-row">
                        <div class="box-content">  
                            <table id="dataTable" class="table table-bordered table-hover">
                               
                                 <tr>
                                 <th scope="col" class="sr-no">Id</th> 
                                 <td scope="row" class="sr-no">{{ $val->id }} </td>
                                 </tr>
                                 
                                 <tr>
                                 <th scope="col">Name</th> 
                                 <td>{{ $val->name }} </td>
                                 </tr>


                                 <tr>
                                 <th scope="col">Added By</th> 
                                 <td>{{ ucwords(@$val->profile->name) }} </td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Type</th> 
                                 <td>{{ $val->type==1?'Solid':($val->type==2?'Liquid':($val->type==3?'Gallon':($val->type==4?'Gas':''))) }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Barcode</th> 
                                 <td>
                                 <img src="data:image/png;base64,{{DNS1D::getBarcodePNG($val->barcode, 'C128',1,70)}}" alt="barcode" />
                                 <br />
                                 {{ $val->barcode }}
                                 </td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Barcode Type</th>
                                 <td>{{ @$val->barcode_type }}</td>
                                 </tr>  
                                 
                                <tr class="{{$val->type==1?'nn':'bck'}}" >
                                    <th scope="col">Serving Size (Unit)</th>
                                    <td>{{ $val->serving_bowl.' '.$val->serving_unit }}</td>
                                </tr>
                            
                                 <tr>
                                 <th scope="col">Calories </th>
                                 <td>{{ $val->calories }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Total Fat (Unit) </th>
                                 <td>{{ $val->total_fat.' '.$val->total_fat_unit }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Sodium (Unit)</th>
                                 <td>{{ $val->sodium.' '.$val->sodium_unit }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Saturated Fat (unit)</th>
                                 <td>{{ $val->saturated_fat.' '.$val->saturated_fat_unit }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Trans Fats (unit)</th>
                                 <td>{{ $val->trans_fat.' '.$val->trans_fats_unit }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Cholestrol (Unit)</th>
                                 <td>{{ $val->cholesterol.' '.$val->cholestrol_unit }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Total Carbohydrates (unit)</th>
                                 <td>{{ $val->total_carbohydrates.' '.$val->total_carbohydrates_unit }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Dietry Fibres (unit)</th>
                                 <td>{{ $val->dietry_fibres.' '.$val->dietry_fibres_unit }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Total Sugars (Unit)</th>
                                 <td>{{ $val->total_sugars.' '.$val->total_sugars_unit }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Added Sugars (unit)</th>
                                 <td>{{ $val->added_sugars.' '.$val->added_sugars_unit }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Protein (unit)</th>
                                 <td>{{ $val->protein.' '.$val->protein_unit }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Vitamin D</th>
                                 <td>{{ $val->vitamin_d }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Calcium (%)</th>
                                 <td>{{ $val->calcium }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Iron (%)</th>
                                 <td>{{ $val->iron }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Vitamin C </th>
                                 <td>{{ $val->vitamin_c }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Potassium (unit)</th>
                                 <td>{{ $val->potassium.' '.$val->potassium_unit }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Daily Value (DV) (%)</th>
                                 <td>{{ $val->daily_value }}</td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Images</th>

                                 <td>
                                 @if(count($val->getImages)>0)
                                    @foreach(@$val->getImages  as $key => $val)
                                    
                                    @php
                                     $infoPath = pathinfo(asset('products/'.@$val->image));
                                    @endphp

                                    @if($infoPath['extension'] == "tif")

                                     <a href="{{ asset('products/'.@$val->image) }}" download>{{ @$val->image }} </a>

                                    @else

                                    <img  height="100px" src="{{ asset('products/'.@$val->image) }}">

                                    @endif  
                                    
                                    @endforeach
                                 @endif   
                                 </td>
                                 </tr>

                                 <tr>
                                 <th scope="col">Created at</th>
                                 <td>{{ $val->created_at }}</td>
                                 </tr>
                   
                                 <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            @include('admin.includes.footer')
        </div>
    </div>
</div>
@endsection

@section('custom_css')
<style>
.nn{
    display:none !important;
}

.bck th, .bck td {
    width: 50%;
}
</style>

@endsection

@section('custom_js')
<script type="text/javascript">
   
</script>
@endsection
