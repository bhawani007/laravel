@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Products</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{route('product.index')}}">Products</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Add</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12 mb-4">
        <div class="fade-in">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header"><strong>Products</strong></div>

                        <div class="card-body">
                         <form name="productform"  action="{{ route('product.store') }}" method="POST" enctype="multipart/form-data">
                           @csrf
                             <div class="row">
                             <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">Name<span style="color:red">*</span></label>
                                       <input type="text" id="name" name="name" value="{{ old('name') }}" class="form-control">
                                       <input type="hidden" name="added_by" value="{{ Auth::user()->id }}">
                                    </div>
                             </div>
                             <div class="col-md-6">   
                                    <div class="form-group">
                                        <label for="type">Type<span style="color:red">*</span></label>
                                        <select name="type" id="type_id" class="form-control">
                                                <option value="2">Liquid</option> 
                                                <option value="1">Solid</option>   
                                        </select>
                                    </div>
                                </div>

                              
                            <div class="col-md-6">
                                <div class="lique-cls">
                                    <div class="form-group">
                                        <label for="serving_bowl">Serving Size</label>
                                        <input type="text" name="serving_bowl" value="{{ old('serving_bowl') }}"  class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="lique-cls">
                                    <div class="form-group">
                                        <label for="ccnumber">Serving (Unit)</label>
                                        <input type="text" name="serving_unit" value="{{ old('serving_unit') }}"  class="form-control">
                                    </div>  
                                </div>
                            </div>  
                                    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="barcode">Barcode<span style="color:red">*</span></label>
                                        <input type="text" id="barcode" name="barcode" value="{{ old('barcode') }}"  class="form-control barcodeno">
                                    </div>
                                </div>
                                <div class="col-md-6">                
                                    <div class="form-group">
                                        <label for="type">Barcode Type<span style="color:red">*</span></label>
                                            <select name="barcode_type" id="barcode_type_id" class="form-control">
                                                <option value="EAN_8">EAN-8</option>   
                                                <option value="EAN_13">EAN-13</option>
                                                <option value="UPC_A">UPC-A</option>
                                                <option value="Other">Other</option>   
                                            </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="ccnumber">Calories<span style="color:red">*</span></label>
                                       <input type="text" id="calories" name="calories" value="{{ old('calories') }}" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="total_fat">Total Fat<span style="color:red">*</span></label>
                                       <input type="text" id="total_fat" name="total_fat" value="{{ old('total_fat') }}"  class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="total_fat_unit">Fat (Unit)</label>
                                        <select name="total_fat_unit" class="form-control">
                                            <option value="gram">gram</option>
                                            <option value="kg">kg</option>
                                        </select>
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Sodium <span style="color:red">*</span> </label>
                                       <input type="text" id="sodium" name="sodium" value="{{ old('sodium') }}"  class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Sodium (Unit)</label>
                                        <select name="sodium_unit" class="form-control">
                                            <option value="mg">mg</option>
                                            <option value="gram">gram</option>
                                            <option value="kg">kg</option>
                                        </select>
                                    </div>
                                    </div>
                                   
                                    <div class="col-md-12">
                                   <div class="form-group">
                                        <label for="barcode">Image</label>
                                        <input type="file" name="image[]" accept="image/*" multiple  class="form-control">
                                    </div> 
                                    </div>

                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Saturated Fat</label>
                                       <input type="text" name="saturated_fat"  class="form-control">
                                    </div>
                                    </div>

                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Saturated Fat (unit)</label>
                                        <select name="saturated_fat_unit" class="form-control">
                                            <option value="gram">gram</option>
                                            <option value="kg">kg</option>
                                        </select>
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="trans_fats">Trans Fats </label>
                                       <input type="text" name="trans_fat" value="{{ old('trans_fat') }}"  class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="trans_fats_unit">Trans Fats (unit)</label>
                                        <select name="trans_fats_unit" class="form-control">
                                            <option value="gram">gram</option>
                                            <option value="kg">kg</option>
                                        </select>
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Cholestrol </label>
                                        <input type="text" name="cholesterol" value="{{ old('cholesterol') }}"  class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">   
                                    <div class="form-group">
                                        <label for="chlestrol">Cholestrol (Unit)</label>
                                        <select name="cholestrol_unit" class="form-control">
                                            <option value="mg">mg</option>
                                            <option value="gram">gram</option>
                                        </select>
                                    </div>
                                    </div>
                                    <div class="col-md-6">    
                                    <div class="form-group">
                                        <label for="ccnumber">Total Carbohydrates </label>
                                       <input type="text" name="total_carbohydrates" value="{{ old('total_carbohydrates') }}" class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Total Carbohydrates (unit)</label>
                                        <select name="total_carbohydrates_unit" class="form-control">
                                            <option value="gm">gm</option>
                                            <option value="mg">mg</option>
                                        </select>
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Dietry Fibres </label>
                                       <input type="text" name="dietry_fibres" value="{{ old('dietry_fibres') }}" class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Dietry Fibres (unit)</label>
                                        <select name="dietry_fibres_unit" class="form-control">
                                            <option value="gm">gm</option>
                                            <option value="kg">kg</option>
                                        </select>
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Total Sugars </label>
                                       <input type="text" name="total_sugars" value="{{ old('total_sugars') }}"  class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Total Sugars (Unit)</label>
                                        <select name="total_sugars_unit" class="form-control">
                                            <option value="gm">gm</option>
                                            <option value="kg">kg</option>
                                        </select>
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Added Sugars </label>
                                       <input type="text" name="added_sugars" value="{{ old('added_sugars') }}"  class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                    <label for="ccnumber">Added Sugars (unit)</label>
                                       <select name="added_sugars_unit" class="form-control">
                                         <option value="gm">gm</option>
                                         <option value="kg">kg</option>
                                       </select>
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Protein </label>
                                       <input type="text" name="protein" value="{{ old('protein') }}" class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Protein (unit)</label>
                                        <select name="protein_unit" class="form-control">
                                            <option value="gm">gm</option>
                                            <option value="kg">kg</option>
                                        </select>
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Vitamin D </label>
                                       <input type="text" name="vitamin_d" value="{{ old('vitamin_d') }}"  class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Calcium (%)</label>
                                       <input type="text" name="calcium" value="{{ old('calcium') }}"  class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Iron (%)</label>
                                       <input type="text" name="iron" value="{{ old('iron') }}"  class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Vitamin C </label>
                                       <input type="text" name="vitamin_c" value="{{ old('vitamin_c') }}" class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Potassium </label>
                                       <input type="text" name="potassium" value="{{ old('potassium') }}"  class="form-control">
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Potassium (unit)</label>
                                       <select name="potassium_unit" class="form-control">
                                         <option value="gm">gm</option>
                                         <option value="kg">kg</option>
                                       </select>
                                    </div>
                                    </div>
                                    <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="ccnumber">Daily Value (DV) (%)</label>
                                       <input type="text" name="daily_value" value="{{ old('daily_value') }}"  class="form-control">
                                    </div>
                                </div>
                                </div>
                                <button type="reset" class="btn btn-sm btn-danger">Reset</button> 
                                <button class="btn btn-sm btn-primary">Submit</button> 
                           </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('admin.includes.footer')
</div>

@endsection

@section('custom_js')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script type="text/javascript">
    $(function () {
        $("#type_id").change(function () {
            if ($(this).val() == 2) {
                $(".lique-cls").show();
            } else {
                $(".lique-cls").hide();
            }
        });

        $(".barcodeno").blur(function(){
            var len = $(this).val().length;
            var barval = '';
            if(len == 8){
            barval  = 'EAN_8';
            }else if(len == 13){
            barval  = 'EAN_13'; 
            }else if(len == 11 || len == 12){
            barval  = 'UPC_A'; 
            }else{
            barval  = 'Other';
            }      
            $("#barcode_type_id").val(barval);
        });


            $("form[name='productform']").validate({
                
                rules: 
                {
                    name      : "required",
                    calories  : "required",
                    total_fat : "required",
                    sodium    : "required",
                    barcode   : "required",       
                },
                
                messages: 
                {
                    name: "Please enter name",
                    calories: "Please enter calories",
                    total_fat: "Please enter total fat",
                    sodium: "Please enter sodium",
                    barcode: "Please enter barcode",
                },
                // Make sure the form is submitted to the destination defined
                // in the "action" attribute of the form when valid
                submitHandler: function(form) {
                form.submit();
                }
                
            });

 });

   
</script>

@endsection