@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Products</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{route('product.index')}}">Products</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12 mb-4">
        <div class="fade-in">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header"><strong>Products</strong></div>

                        <div class="card-body">
                         <form action="{{ route('product.update',$pro->id) }}" method="POST" enctype="multipart/form-data">
                         @csrf
                             <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Name<span style="color:red">*</span></label>
                                       <input type="text" name="name" value="{{ $pro->name }}" class="form-control">
                                       <input type="hidden" name="added_by" value="{{ Auth::user()->id }}">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="type">Type<span style="color:red">*</span></label>
                                       <select name="type"  id="type_id" class="form-control">
                                            <option value="2" {{ $pro->type ==2?'selected':'' }} >Liquid</option>     
                                            <option value="1" {{ $pro->type ==1?'selected':'' }}>Solid</option>      
                                        </select>
                                    </div>
                                </div>  

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="lique-cls">
                                            <label for="ccnumber">Serving Size</label>
                                            <input type="text" name="serving_bowl" value="{{ $pro->serving_bowl }}" class="form-control">
                                        </div>
                                    </div>  
                                </div>

                                <div class="col-md-6">  
                                    <div class="form-group">
                                        <div class="lique-cls">
                                            <label for="ccnumber">Serving (Unit)</label>
                                            <input type="text" name="serving_unit" value="{{ !empty($pro->serving_unit)?$pro->serving_unit:'' }}" class="form-control">
                                        </div>
                                    </div>  
                                </div>         
                                     
                                <div class="col-md-6"> 
                                    <div class="form-group">
                                        <label for="barcode">Barcode<span style="color:red">*</span></label>
                                       <input type="text" name="barcode" value="{{ $pro->barcode }}"  class="form-control barcodeno">
                                    </div>
                                </div>  

                                <div class="col-md-6"> 
                                    <div class="form-group">
                                        <label for="type">Barcode Type<span style="color:red">*</span></label>
                                            <select name="barcode_type" id="barcode_type_id" class="form-control">
                                                <option value="EAN_8"  {{ $pro->barcode_type =='EAN_8'?'selected':'' }}>EAN-8</option>   
                                                <option value="EAN_13" {{ $pro->barcode_type =='EAN_13'?'selected':'' }}  >EAN-13</option>
                                                <option value="UPC_A"  {{ $pro->barcode_type =='UPC_A'?'selected':'' }}>UPC-A</option>
                                                <option value="Other"  {{ $pro->barcode_type =='Other'?'selected':'' }}>Other</option>   
                                            </select>
                                    </div>
                                </div>  

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="ccnumber">Calories<span style="color:red">*</span></label>
                                       <input type="text" name="calories" value="{{ $pro->calories }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6"> 
                                    <div class="form-group">
                                        <label for="ccnumber">Total Fat<span style="color:red">*</span></label>
                                       <input type="text" name="total_fat" value="{{ $pro->total_fat }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6"> 
                                    <div class="form-group">
                                        <label for="ccnumber">Fat (Unit)</label>
                                        <select name="total_fat_unit" class="form-control">
                                            <option value="gram" {{ $pro->total_fat_unit =='gram'?'selected':'' }}>gram</option>
                                            <option value="kg" {{ $pro->total_fat_unit =='kg'?'selected':'' }}>kg</option>
                                        </select>
                                    </div>
                                </div>    

                                <div class="col-md-6"> 
                                    <div class="form-group">
                                        <label for="ccnumber">Sodium<span style="color:red">*</span> </label>
                                       <input type="text" name="sodium" value="{{ $pro->sodium }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Sodium (Unit)</label>
                                            <select name="sodium_unit" class="form-control">
                                                <option value="mg"  {{ $pro->sodium_unit =='mg'?'selected':'' }}>mg</option>
                                                <option value="gram" {{ $pro->sodium_unit =='gram'?'selected':'' }}>gram</option>
                                                <option value="kg" {{ $pro->sodium_unit =='kg'?'selected':'' }}>kg</option>
                                            </select>
                                    </div>
                                </div>    

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="barcode">Image</label>
                                       <input type="file" name="image[]" accept="image/*" multiple  class="form-control">
                                       @foreach($pro->getImages as $ke => $va)

                                       <img height="70px" src="{{ asset('products/'.@$va->image) }}">

                                       @endforeach
                                    </div>
                                </div>    

                                <div class="col-md-6"> 
                                    <div class="form-group">
                                        <label for="ccnumber">Saturated Fat</label>
                                       <input type="text" name="saturated_fat" value="{{ $pro->saturated_fat }}" class="form-control">
                                    </div>
                                </div>   

                                <div class="col-md-6"> 
                                    <div class="form-group">
                                        <label for="ccnumber">Saturated Fat (unit)</label>
                                            <select name="saturated_fat_unit" class="form-control">
                                                <option value="gram" {{ $pro->saturated_fat_unit =='gram'?'selected':'' }}>gram</option>
                                                <option value="kg"   {{ $pro->saturated_fat_unit =='kg'?'selected':'' }}>kg</option>
                                            </select>
                                    </div>
                                </div> 

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Trans Fats </label>
                                       <input type="text" name="trans_fat" value="{{ $pro->trans_fat }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Trans Fats (unit)</label>
                                        <select name="trans_fats_unit" class="form-control">
                                            <option value="gram" {{ $pro->trans_fats_unit =='gram'?'selected':'' }}>gram</option>
                                            <option value="kg" {{ $pro->trans_fats_unit =='kg'?'selected':'' }}>kg</option>
                                        </select>
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Cholestrol </label>
                                       <input type="text" name="cholesterol" value="{{ $pro->cholesterol }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Cholestrol (Unit)</label>
                                        <select name="cholestrol_unit" class="form-control">
                                            <option value="mg" {{ $pro->cholestrol_unit =='mg'?'selected':'' }}>mg</option>
                                            <option value="gram" {{ $pro->cholestrol_unit =='gram'?'selected':'' }}>gram</option>
                                        </select>
                                    </div>
                                </div>   

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Total Carbohydrates </label>
                                       <input type="text" name="total_carbohydrates" value="{{ $pro->total_carbohydrates }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Total Carbohydrates (unit)</label>
                                       <select name="total_carbohydrates_unit" class="form-control">
                                         <option value="gm" {{ $pro->total_carbohydrates_unit =='gm'?'selected':'' }}>gm</option>
                                         <option value="mg" {{ $pro->total_carbohydrates_unit =='mg'?'selected':'' }}>mg</option>
                                       </select>
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Dietry Fibres </label>
                                       <input type="text" name="dietry_fibres" value="{{ $pro->dietry_fibres }}" class="form-control">
                                    </div>
                                </div>   

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Dietry Fibres (unit)</label>
                                       <select name="dietry_fibres_unit" class="form-control">
                                         <option value="gm" {{ $pro->dietry_fibres_unit =='gm'?'selected':'' }}>gm</option>
                                         <option value="kg" {{ $pro->dietry_fibres_unit =='kg'?'selected':'' }}>kg</option>
                                       </select>
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Total Sugars </label>
                                       <input type="text" name="total_sugars" value="{{ $pro->total_sugars }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6"> 
                                    <div class="form-group">
                                        <label for="ccnumber">Total Sugars (Unit)</label>
                                       <select name="total_sugars_unit" class="form-control">
                                         <option value="gm" {{ $pro->total_sugars_unit =='gm'?'selected':'' }}>gm</option>
                                         <option value="kg" {{ $pro->total_sugars_unit =='kg'?'selected':'' }}>kg</option>
                                       </select>
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Added Sugars </label>
                                       <input type="text" name="added_sugars" value="{{ $pro->added_sugars }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="added_sugars_unit">Added Sugars (unit)</label>
                                       <select name="added_sugars_unit" class="form-control">
                                         <option value="gm" {{ $pro->added_sugars_unit =='gm'?'selected':'' }}>gm</option>
                                         <option value="kg" {{ $pro->added_sugars_unit =='kg'?'selected':'' }}>kg</option>
                                       </select>
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="protein">Protein </label>
                                       <input type="text" name="protein" value="{{ $pro->protein }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="protein_unit">Protein (unit)</label>
                                       <select name="protein_unit" class="form-control">
                                         <option value="gm" {{ $pro->protein_unit =='gm'?'selected':'' }}>gm</option>
                                         <option value="kg" {{ $pro->protein_unit =='kg'?'selected':'' }}>kg</option>
                                       </select>
                                    </div>
                                </div>   

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Vitamin D </label>
                                       <input type="text" name="vitamin_d" value="{{ $pro->vitamin_d }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Calcium (%)</label>
                                       <input type="text" name="calcium" value="{{ $pro->calcium }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Iron (%)</label>
                                       <input type="text" name="iron" value="{{ $pro->iron }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Vitamin C </label>
                                       <input type="text" name="vitamin_c" value="{{ $pro->vitamin_c }}" class="form-control">
                                    </div>
                                </div>   

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Potassium </label>
                                       <input type="text" name="potassium" value="{{ $pro->potassium }}" class="form-control">
                                    </div>
                                </div>    

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ccnumber">Potassium (unit)</label>
                                        <select name="potassium_unit" class="form-control">
                                            <option value="gm" {{ $pro->potassium_unit =='gm'?'selected':'' }}>gm</option>
                                            <option value="kg" {{ $pro->potassium_unit =='kg'?'selected':'' }}>kg</option>
                                        </select>
                                    </div>
                                </div>    

                                     <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="ccnumber">Daily Value (DV) (%)</label>
                                             <input type="text" name="daily_value" value="{{ $pro->daily_value }}" class="form-control">
                                        </div>
                                     </div>
                                     <button type="reset" class="btn btn-sm btn-danger">Reset</button> 
                                    <button class="btn btn-sm btn-primary">Submit</button>  
                                </div> 
                            </div>
                            
                          </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('admin.includes.footer')
</div>

@endsection

@section('custom_js')

<script type="text/javascript">
   $(function () {

        if($("#type_id").val() == 1 )
        {  $(".lique-cls").hide();
        }

        $("#type_id").change(function () {
            if ($(this).val() == 2) {
                $(".lique-cls").show();
            } else {
                $(".lique-cls").hide();
            }
        });


        $(".barcodeno").blur(function(){
            var len = $(this).val().length;
            var barval = '';
            if(len == 8){
              barval  = 'EAN_8';
            }else if(len == 13){
              barval  = 'EAN_13'; 
            }else if(len == 11 || len == 12){
              barval  = 'UPC_A'; 
            }else{
              barval  = 'Other';
            }      
            $("#barcode_type_id").val(barval);
        });


    });

</script>

@endsection