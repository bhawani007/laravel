
@extends('admin.layouts.default')
@section('content')
<div class="page-title col-sm-12">
   <div class="row align-items-center">
      <div class="col-md-6">
         <h1 class="h3 m-0">Customers</h1>
      </div>
      <div class="col-md-6">
         <nav aria-label="breadcrumb">
            <ol class="breadcrumb m-0 p-0">
               <li class="breadcrumb-item"><a href="">Home</a></li>
               <li class="breadcrumb-item active" aria-current="page">Customer</li>
            </ol>
         </nav>
      </div>
   </div>
</div>
<div class="row">
   <div class="col-lg-12">
      <div class="card">
         <div class="card-header">Customer List
         <a href="{{route('product.import.data')}}"><span style="margin-left: 10px" class="badge badge-primary float-right"><i class="far fa-long-arrow-up"></i> Import</span></a>
                <a href="{{ route('product.export') }}"><span style="margin-left: 10px" class="badge badge-primary float-right"><i class="far fa-long-arrow-down"></i> Export</span></a>
                <a href="{{route('product.add')}}"><span style="margin-left: 10px" class="badge badge-primary float-right">Add</span></a>
                <a href="{{ asset('storage/sample.xlsx') }}" download style="margin-left: 10px" class="badge badge-primary float-right">Download Sample</a>
         </div>
         <div class="card-body">

         

            <table id="dataTable" class="table table-striped table-bordered table-hover">
               <thead>
                  <tr>
                    <th scope="col" class="sr-no">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Type </th>
                    <th scope="col">Barcode</th>
                    <th scope="col">Barcode Type</th>
                    <th scope="col">Serving Bowl (Unit)</th>
                    <th scope="col">Calories </th>
                    <th scope="col">Total Fat (Unit) </th>
                    <th scope="col">Sodium (Unit)</th>
                    <th scope="col" class="action">Action</th>
                  </tr>
               </thead>
               <tbody>
               @foreach($listpro as $key => $val)
                                
                                <tr>
                                    <td scope="row" class="sr-no">{{$key+1}} </td>
                                    <td>{{ $val->name }}</td>
                                    <td>{{ $val->type==1?'Solid':($val->type==2?'Liquid':($val->type==3?'Gallon':($val->type==4?'Gas':''))) }}</td>
                                    <td><img height="75" src="data:image/png;base64,{{DNS1D::getBarcodePNG($val->barcode, 'C128',1,110)}}" alt="barcode" />
                                    <br/>{{ $val->barcode }}</td>
                                    <td>{{ @$val->barcode_type }}</td>
                                    <td>{{ $val->serving_bowl.' '.$val->serving_unit }}</td>
                                    <td>{{ $val->calories }}</td>
                                    <td>{{ $val->total_fat.' '.$val->total_fat_unit }}</td>
                                    <td>{{ $val->sodium.' '.$val->sodium_unit }}</td>
                                    <td class="action">
                                        <button type="button" class="icon-btn preview"><a href="{{ route('product.view',$val->id) }}"><i class="fal fa-eye"></i></a></button>
                                        <button type="button" class="icon-btn edit"><a href="{{ route('product.edit',$val->id) }}"><i class="fal fa-edit"></i></a></button>
                                        <button onclick="GetAction('{{ route('product.delete',$val->id) }}')"  type="button" class="icon-btn delete"><i class="fal fa-times"></i></button>
                                    </td>
                                </tr>

                           @endforeach   
               </tbody>
            </table>
         </div>
      </div>
   </div>
</div>



   


    <!-- Modal -->
<div class="modal fade" id="BulkStatusData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Customer Status</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Status:</label>
             <select name="status" id="bulk_status_id" class="form-control required">
             <option   value="Active">Active</option>
             <option  value="Inactive">Inactive</option>
             <option  value="Approved">Approved</option>
             <option  value="Locked">Locked</option>
             <option  value="Hold">Hold</option>
            </select>

          </div>
        </form>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="save_bulk_id">Save changes</button>
      </div>
      </div>
     
    </div>
  </div>
</div>


<!-- Import customer data -->
<div class="modal fade" id="importModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Import Excel</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <form action="" method="post" enctype="multipart/form-data">
               @csrf
               <div class="form-group">
                  <label>Choose Excel</label>
                  <input class="form-control" type="file" name="import_excel"
                     autocomplete="import_excel">
               </div>
               <button class="btn btn-sm btn-primary" type="submit">Submit</button>
               <button class="btn btn-sm btn-danger" type="reset">Reset</button>
            </form>
         </div>        
      </div>
   </div>
</div>



@endsection


@section("custom_js")
<script type="text/javascript">
    $(function() {
        $('#dataTable').DataTable();
        console.log('---index page---');
    })
</script>

@endsection

