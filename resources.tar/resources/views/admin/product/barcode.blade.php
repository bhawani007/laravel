<html>	
	<head>
		<title>Barcode - Websolutionstuff</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	</head>
	<h1 class="text-primary" style="text-align: center;margin-bottom: 20px;">Laravel Barcode</h1>
	<div style="text-align: center;">
		<img src="data:image/png;base64,{{DNS1D::getBarcodePNG('2 3 4 5 8 5 1 4 5 6 5634 345', 'C39')}}" alt="barcode" /><br><br>
		<img src="data:image/png;base64,{{DNS1D::getBarcodePNG('2 3 4 5 8 5 1 4 5 6 5634 345', 'C39+',1,33,array(0,255,0), true)}}" alt="barcode" /><br><br>
		<img src="data:image/png;base64,{{DNS1D::getBarcodePNG('2 3 4 5 8 5 1 4 5 6 5634 345', 'C39+',3,33,array(100,0,0))}}" alt="barcode" /><br><br>
		<img src="data:image/png;base64,{{DNS1D::getBarcodePNG('12', 'C39+')}}" alt="barcode" /><br><br>
		<img src="data:image/png;base64,{{DNS1D::getBarcodePNG('23', 'POSTNET')}}" alt="barcode" /><br/><br/>
	</div>
</html>