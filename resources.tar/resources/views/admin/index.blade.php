@extends('admin.layouts.login')
@section('content')
<div class="login-page">
        <div class="login-box">
            <div class="contentBox">
                <!-- <div class="logo d-flex flex-wrap w-100">
                    <img src="images/logo.svg" alt="logo">
                </div> -->
                <h1>Welcome to Fitness App</h1>
                <p>Enter your email address and password to access admin panel.</p>
                <form class="mt-4" action="{{route('login')}}" method="post">
                @csrf
                    <div class="form-group">
                        <label>Email Address</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fal fa-envelope"></i></span>
                            </div>
                            <input type="text" name ="email" class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="form-group">
                        <!-- <label>Password <a class="float-right" href="forgot.html">Forgot your password?</a></label> -->
                        <label>Password</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fal fa-lock"></i></span>
                            </div>
                            <input type="password" name="password" id="password" class="form-control" placeholder="">
                            <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-check">
                            <label class="form-check-label" for="exampleCheck1"><a href="{{ route('guest-forgot-password') }}">Forgot Password</a></label>
                        </div>
                    </div>
                    <div class="form-group mb-0">
                        <button type="submit" class="btn btn-primary w-100">Login</button>
                    </div>
                </form>
            </div>
            <div class="imgBox d-none d-md-block">
                <img src="images/cover.png" alt="image">
            </div>
        </div>
    </div>
 @endsection   


@section('admin_custom_js')
        <script type="text/javascript">
            $(document).ready(function () {
                $(document).on('click', '.toggle-password', function () {
                    $(this).toggleClass("fa-eye fa-eye-slash");
                    var input = jQuery("#password");
                    input.attr('type') === 'password' ? input.attr('type', 'text') : input.attr('type', 'password')
                });
            });
        </script>
@endsection     


@section('admin_custom_css')

<style>
    .input-group span.field-icon {
        position: absolute;
        top: 14px;
        right: 10px;
        float: right;
        z-index: 999;
    }
    .form-check {
        padding-left: 0;
    }
    .input-group #password {
        padding-right:40px;
        border-top-right-radius: .25rem;
        border-bottom-right-radius: .25rem;
    }
</style>

@endsection