<script type="text/javascript" src="{{asset('js/bootstrap.bundle.js')}}"></script>
<script type="text/javascript" src="{{asset('js/script.js')}}"></script>
<script type="text/javascript" src="{{asset('js/moment.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/daterangepicker.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/select2.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/sweetalert2@8.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery-ui.js')}}"></script>
<script type="text/javascript" src="{{ asset('js/jquery.validate.min.js') }}"></script>

<script>

function GetAction(param) 
{
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to perform this action? This action cannot be undone.",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.value) {
                Swal.fire(
                    'Deleted!',
                    '',
                    'success'
                )
                window.location = param
            }
    })
}

</script>









