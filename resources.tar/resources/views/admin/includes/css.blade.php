<link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('css/fontawesome.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('css/style.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('css/daterangepicker.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('css/select2.min.css')}}" rel="stylesheet" /> 
<link href="{{asset('css/custom.css')}}" rel="stylesheet" />
<link href="{{asset('css/jquery-ui.css')}}" rel="stylesheet" />
<script type="text/javascript" src="{{asset('js/jquery.min.js')}}"></script>   
<script type="text/javascript" src="{{asset('js/jquery.dataTables.min.js')}}"></script>
<div id="pageloader">
   <img src="{{ asset('images/loader-large.gif') }}" alt="processing..." />
</div>

<style>

#pageloader
{
  background: rgba( 255, 255, 255, 0.8 );
  display: none;
  height: 100%;
  position: fixed;
  width: 100%;
  z-index: 9999;
}

#pageloader img
{
  left: 50%;
  margin-left: -32px;
  margin-top: -32px;
  position: absolute;
  top: 50%;
}

</style>









