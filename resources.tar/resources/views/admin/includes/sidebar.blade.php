{{ $routeName =  \Request::route()->getName() }}
<div class="dashboard-menu">
    <div class="nav-menu">
        <div class="user-info"> 
            <div class="user-icon"><img src="{{ asset('images/'.getPic()) }}" alt="img"></div>
            <div class="user-name">
                <h5>John S</h5>
                <span class="h6 text-muted">Administrator</span>
            </div>
        </div>
        <ul class="list-unstyled nav">
            <li class="nav-item"><span class="menu-title text-muted">NAVIGATION</span></li>
            <li class="nav-item"><a href="{{route('dashboard')}}" class="nav-link"><i class="fa fa-home" aria-hidden="true"></i> Dashboard</a></li>
            <li class="nav-item @if($routeName == 'user.index' || $routeName == 'user.add' || $routeName == 'user.edit' || $routeName == 'user.view') active @endif"><a href="{{route('user.index')}}" class="nav-link"><i class="fa fa-user" aria-hidden="true"></i>User Manager</a></li>
            <li class="nav-item @if($routeName == 'product.index' || $routeName == 'product.add' || $routeName == 'product.edit' || $routeName == 'product.view') active @endif"><a href="{{route('product.index')}}" class="nav-link"><i class="fab fa-product-hunt" aria-hidden="true"></i>Product Manager</a></li>
            <li class="nav-item"><a href="{{ route('system.setting') }}" class="nav-link"><i class="fa fa-cog"></i>System Setting</a></li>
            <li class="nav-item @if($routeName == 'cms-pages.index' || $routeName == 'cms-pages.create' || $routeName == 'cms-pages.edit' || $routeName == 'cms-pages.show') active @endif"><a href="{{ route('cms-pages.index') }}" class="nav-link"><i class="fa fa-file" aria-hidden="true"></i>CMS Pages</a></li>
             <li class="nav-item @if($routeName == 'membership.index' || $routeName == 'membership.create' || $routeName == 'membership.edit' || $routeName == 'membership.show') active @endif"><a href="{{ route('membership.index') }}" class="nav-link">
             <i class='fas fa-handshake'></i>Membership</a></li>
             <!-- <li class="nav-item @if($routeName == 'notification.index') active @endif"><a href="{{ route('notification.index') }}" class="nav-link"><i class="fa fa-bell" aria-hidden="true"></i>
            Notifications</a></li> -->
             <li class="nav-item @if($routeName == 'exercises.index' || $routeName == 'exercises.create' || $routeName == 'exercises.edit' || $routeName == 'exercises.show' || $routeName == 'sub-exercise.index' || $routeName == 'sub-exercise.create' || $routeName == 'sub-exercise.show' || $routeName == 'sub-exercise.edit') active @endif"><a href="#" class="nav-link"><i class="far fa-running" aria-hidden="true"></i> Exercise </a>
                <ul class="sub-menu">
                    <li class="nav-item @if($routeName == 'exercises.index' || $routeName == 'exercises.create' || $routeName == 'exercises.edit' || $routeName == 'exercises.show') active @endif"><a href="{{ route('exercises.index') }}" class="nav-link">Exercise Level 1</a></li>
                    <li class="nav-item @if($routeName == 'sub-exercise.index' || $routeName == 'sub-exercise.create' || $routeName == 'sub-exercise.edit' || $routeName == 'sub-exercise.show') active @endif"><a href="{{ route('sub-exercise.index') }}" class="nav-link">Exercise Level 2</a></li>
                </ul>
            </li>

            <li class="nav-item @if($routeName == 'goals.index' || $routeName == 'goals.create' || $routeName == 'goals.edit' || $routeName == 'goals.show' || $routeName == 'goal-routines.index' || $routeName == 'goal-routines.create' || $routeName == 'goal-routines.show' || $routeName == 'goal-routines.edit' || $routeName == 'goal-habits.index' || $routeName == 'goal-habits.create' || $routeName == 'goal-habits.show' || $routeName == 'goal-habits.edit') active @endif"><a href="#" class="nav-link"><i class="fa fa-bullseye" aria-hidden="true"></i> Goals </a>
                <ul class="sub-menu">
                    <li class="nav-item @if($routeName == 'goals.index' || $routeName == 'goals.create' || $routeName == 'goals.edit' || $routeName == 'goals.show') active @endif"><a href="{{ route('goals.index') }}" class="nav-link">Weight Goal</a></li>
                    <li class="nav-item @if($routeName == 'goal-routines.index' || $routeName == 'goal-routines.create' || $routeName == 'goal-routines.edit' || $routeName == 'goal-routines.show') active @endif"><a href="{{ route('goal-routines.index') }}" class="nav-link">Exercise routine</a></li>
                    <li class="nav-item @if($routeName == 'goal-habits.index' || $routeName == 'goal-habits.create' || $routeName == 'goal-habits.edit' || $routeName == 'goal-habits.show') active @endif"><a href="{{ route('goal-habits.index') }}" class="nav-link">Food habits</a></li>
                </ul>
            </li>
           
        </ul>
    </div>
</div>