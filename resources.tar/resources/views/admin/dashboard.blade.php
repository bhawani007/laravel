@extends('admin.layouts.default')
@section('content')


<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Dashboard</h1>
            </div>
          
        </div>
    </div>
    <div class="col-sm-12">
        <div class="row">
            <div class="col-xl-4 col-md-6 mb-4">
                <div class="box bg-white">
                    <div class="box-row flex-wrap">
                        <div class="box-content">
                            <h6>Total Products</h6>
                            <p class="h1 m-0"><a href="{{ route('product.index') }}">{{ totalProduct() }}</a></p>
                        </div>
                        <div class="box-icon chart">
                          Added by Admin by --  {{  totalProductAddedAdmin() }}
                            <br>
                          Added by User by -- {{ totalProductAddedUser() }}
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6 mb-4">
                <div class="box bg-white">
                    <div class="box-row flex-wrap">
                        <div class="box-content">
                            <h6>Total User</h6>
                            <p class="h1 m-0"><a href="{{ route('user.index') }}">{{ totalUser() }}</a></p>
                        </div>
                        <div class="box-icon chart">
                            <div id="product-sold" style='width: 100%; height: 100px;'></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6 mb-4">
                <div class="box bg-white">
                    <div class="box-row flex-wrap">
                        <div class="box-content">
                            <h6>Total Exercise</h6>
                            <p class="h1 m-0"><a href="{{ route('exercises.index') }}">{{ totalExercise() }}
                            
                            
                            
                            <?php
                            $pie ='';
                             foreach(getExercise() as $key => $info)
                             {
                                $n = $info->exName;
                                $t = $info->Total;
                                $pie   .=  "['$n',$t],";
                             }
                            ?>
                            
                            </a></p>
                        </div>
                        <div class="box-icon chart">
                            <div id="new-customer" style='width: 100%; height: 100px;'></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 mb-6">
                <div class="box bg-white">
                    <div class="box-title">
                        <h5>Preferable exercise choosen by user</h5>
                        <div class="box-action dropdown" data-toggle="tooltip" data-placement="left">
                            <!--<button class="more-action dropdown-toggle" type="button" data-toggle="dropdown"
                                aria-haspopup="false" aria-expanded="false"><i class="fal fa-ellipsis-v"></i></button>
                             <div class="dropdown-menu dropdown-menu-right">
                                <a href="#" class="dropdown-item"><i class="fal fa-sync-alt"></i> Refresh</a>
                            </div> -->
                        </div>
                    </div>
                    <div class="box-row">
                        <div class="box-content">
                            <!-- <div id="overview-chart" style="width: 100%; height: 300px;"></div> -->
                            <div id="piechart" style="width: 100%; height: 300px;"></div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="col-md-4 mb-4">
                <div class="box bg-white">
                    <div class="box-title">
                        <h5>Targets</h5>
                    </div>
                    <div class="box-row">
                        <div class="box-content">
                            <div id="targets-chart" style="width: 100%; height: 300px;"></div>
                        </div>
                    </div>
                </div>
            </div> -->
            <div class="col-md-6 mb-6">
                <div class="box bg-white">
                    <div class="box-title">
                        <h5>Notifications</h5>
                        <!-- <div class="box-action">
                            <a href="#" class="btn small">View All</a>
                        </div> -->
                    </div>
                    <div class="box-row flex-wrap boxScroll" style="max-height: 300px;">
                        <div class="wrap">  
                          @foreach(todayUsers() as $key => $val)    
                            <div class="box-content mb-2">
                                <p class="m-0">{{ ucwords($val->name) }} registed successfully today</p>
                                <span class="text-muted h6">{{ $val->created_at }}</span>
                            </div>
                          @endforeach  


                         @foreach(todayProducts() as $key => $val)
                         <div class="box-content mb-2">
                                <p class="m-0">Product {{ ucwords($val->name) }} added successfully today</p>
                                <span class="text-muted h6">{{ $val->created_at }}</span>
                            </div>
                         @endforeach

                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="col-md-4 mb-4">
                <div class="box bg-white">
                    <div class="box-title">
                        <h5>Overview</h5>
                    </div>
                    <div class="box-row">
                        <div class="box-content">
                            <h3>121,000</h3>
                            <span class="text-muted">Total Visitors</span>
                        </div>
                        <div class="box-icon">
                            <i class="fal fa-users"></i>
                        </div>
                    </div>
                    <div class="box-row">
                        <div class="box-content">
                            <h3>21,000</h3>
                            <span class="text-muted">Total Product Views</span>
                        </div>
                        <div class="box-icon">
                            <i class="fal fa-users"></i>
                        </div>
                    </div>
                    <div class="box-row">
                        <div class="box-content">
                            <h3>$21.5</h3>
                            <span class="text-muted">Revenue Per Visitor</span>
                        </div>
                        <div class="box-icon">
                            <i class="fal fa-users"></i>
                        </div>
                    </div>
                </div>
            </div> -->
            <!-- <div class="col-md-8 mb-4">
                <div class="box bg-white">
                    <div class="box-title">
                        <h5>Revenue</h5>
                    </div>
                    <div class="box-row">
                        <div class="box-content">
                            <div id="revenue-chart" style="width: 100%; height: 300px;"></div>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
    @include('admin.includes.footer')
</div>

@endsection

@section('custom_css')
<style>
    .box .box-row .box-icon {
        font-size:20px;
        text-align: left;
        color:#000;
    }
    .box {
        height: 90%;
    }
</style>

@endsection

@section('custom_js')
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type='text/javascript'>
    $(function () {
        $('input.date-range').daterangepicker({
            "startDate": "01/03/2020",
            "endDate": "01/09/2020",
            opens: 'left'
        });
    });
    

    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['option', 'revenue'],
            ['Revenue', 2189],
            ['Product Sold', 1200],
            ['New User', 5],
            ['New Visitors', 720]
        ]);

        var options = {
            curveType: 'function',
            legend: { position: 'bottom' }
        };

        var chart1 = new google.visualization.LineChart(document.getElementById('today-revenue'));
        var chart2 = new google.visualization.LineChart(document.getElementById('product-sold'));
        var chart3 = new google.visualization.LineChart(document.getElementById('new-customer'));
        var chart4 = new google.visualization.LineChart(document.getElementById('new-visitors'));
        var chart5 = new google.visualization.PieChart(document.getElementById('overview-chart'));
        var chart6 = new google.visualization.ColumnChart(document.getElementById('targets-chart'));
        var chart7 = new google.visualization.LineChart(document.getElementById('revenue-chart'));

        chart1.draw(data, options);
        chart2.draw(data, options);
        chart3.draw(data, options);
        chart4.draw(data, options);
        chart5.draw(data, options);
        chart6.draw(data, options);
        chart7.draw(data, options);
    }
</script>


<!---pie chart for exercise --->

<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', ''],
          <?php echo $pie;?>
        ]);

        var options = {
          title: ''
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>

@endsection