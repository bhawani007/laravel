@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Sub Exercise</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{route('sub-exercise.index')}}">Sub Exercise</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12 mb-4">
        <div class="fade-in">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header"><strong>Sub Exercise</strong></div>

                        <div class="card-body">

                       
                        <div class="btn-block">
                        <!-- <button style="" class="btn btn-sm btn-primary" type="submit" id="append" name="append">
                        Add</button> -->
                        </div>
                         <form action="javascript:void(0)" method="POST" enctype="multipart/form-data" id="formId">
                           @csrf
                             <div class="row">
                                <div class="col-md-12">
                                        <div class="form-group"> 
                                          <label for="name">Exercise Level 1<span style="color:red">*</span></label> 
                                            <select name="exercise_id" class="form-control">
                                            @foreach(@$exercise as $key => $val) 
                                                <option value="{{ $val->id }}" {{ @$info[0]->exercise_id ==  @$val->id ?'selected':'' }}>{{  $val->name }}</option>  
                                            @endforeach 
                                            </select>    
                                        </div>
                                </div>
          
                              
                            @foreach(@$info as $key => $val) 
                                <div class="col-md-12">
                                          <div class="inc">
                                                <div class="controls row">
                                                    <div class="form-group col-md-4">
                                                        <label for="name">Name<span style="color:red">*</span></label> 
                                                        <input type="text" class="form-control" value="{{ @$val['name'] }}" name="name[]"/> 
                                                        <input type="hidden" id="tt_fields" value="{{ old('tal_f') }}" class="form-control" name="tal_f" /> 
                                                        <input type="hidden" id="ex_id" value="{{ @$info[0]->exercise_id }}"  name="exer_id" /> 
                                                        <input type="hidden"  value="{{ @$info[$key]->id }}"  name="ids[]" /> 
                                                    </div>

                                                    <div class="form-group col-md-3">
                                                      <label for="video">Video<span style="color:red">*</span></label> 
                                                      <input type="file" class="form-control" name="videos[]" value="{{ @$val['video'] }}" />
                                                      <input type="hidden"  accept="video/* class="form-control" name="videos[]" value="{{ @$val['video'] }}" />
                                                        <video width="160" height="80" controls>
                                                        <source src="{{ asset('subexercise/'.@$val['video']) }}" type="video/mp4">
                                                        src="{{asset('video/abc/jp.mp4')}}"
                                                        <source src="{{ asset('public/subexercise/'.@$val['video']) }}" type="video/ogg">
                                                        </video>
                                                    </div>    

                                                    <div class="form-group col-md-4">
                                                      <label for="description">Description<span style="color:red">*</span></label> 
                                                      <textarea class="form-control" name="description[]">{{ @$val['description'] }}</textarea>
                                                    </div>  
                                                    <!-- <div class="col-md-1">
                                                    <button onclick="GetAction('{{ route('sub.exercises.delete',@$info[$key]->id) }}')"  type="button" class="remove_this btn btn-danger"><i class="fal fa-times"></i></button>
                                                    </div>   -->
                                                </div>
                                          </div>
                                </div>
                             @endforeach   

                            


                             </div>
                                <button type="reset" class="btn btn-sm btn-danger">Reset</button> 
                                <button class="btn btn-sm btn-primary" id="send_data">Submit</button> 
                           </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('admin.includes.footer')
</div>

@endsection

@section('custom_css')

<style>
.fade-in .btn-block {
    display: block;
    width: 100%;
    text-align: right;
}
.remove_this.btn.btn-danger {
    margin-top:32px;
}

</style>
@endsection

@section('custom_js')
<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>

<script type="text/javascript">
      var total_f  = 0;
     $( function() {
       // CKEDITOR.replace( 'description' );

       
      $("#append").click( function(e) {
        ++total_f; 
        $("#tt_fields").val(total_f);
      e.preventDefault();
      $(".inc:last").after('<div class="controls row">\
         <div class="form-group col-md-4"> <label for="name">Name<span style="color:red">*</span></label><input type="hidden"  value="0"  name="ids[]" /> <input class="form-control" type="text" value="{{ old('".name."') }}" name="name[]"></div>\
         <div class="form-group col-md-3"> <label for="video">Video<span style="color:red">*</span></label> <input class="form-control" type="file" value="" accept="video/*" name="videos[]"></div>\
         <div class="form-group col-md-4"> <label for="description">Description<span style="color:red">*</span></label> <textarea class="form-control" name="description[]"></textarea></div>\
         <div class="col-md-1 mb-4 text-right"><a href="#" class="remove_this btn btn-danger"><i class="fal fa-times"></i></a></div> \
      </div>');
      return false;
      });

      $(document).on('click', '.remove_this', function() {
        $(this).parent().parent().remove();
        return false;
      });


      $('#send_data').click(function(e){
        e.preventDefault();
        /*Ajax Request Header setup*/
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var formData  = new FormData($('#formId')[0]);
   
   /* Submit form data using ajax*/
   $.ajax({
      url: "{{ route('sub-exercise.update') }}",
      method: 'post',
     // dataType: 'JSON',
      data: formData,
      cache:false,
      contentType: false,
      processData: false,
      success: function(response){
            var finallymsg ='';
            if(response.status=='success')
            {
                finallymsg = response.msg;
                 document.getElementById("formId").reset(); 
            }
            else
            {
                $.each(response.msg, function( key, value )
                 {
                    finallymsg += value+'<br>';
                });
            }
           
        
            (function () {
                Lobibox.notify(response.status, {
                    rounded: false,
                    delay: 4000,
                    delayIndicator: true,
                    msg: finallymsg
                });
            })();
        
            if(response.status=='success')
            {
                setTimeout(function(){
                  window.location.href = "{{ route('sub-exercise.index') }}"
                },3000); 
            }
            
    
      }});
   });

  });
</script>

@endsection