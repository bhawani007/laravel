@extends('admin.layouts.default')
@section('content')

<div class="main-content">
    <div class="page-title col-sm-12">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3 m-0">Sub Exercise</h1>
            </div>
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{route('sub-exercise.index')}}">Sub Exercise</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Add</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="col-sm-12 mb-4">
        <div class="fade-in">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header"><strong>Sub Exercise</strong></div>

                        <div class="card-body">

                       
                        <div class="btn-block">
                        <!-- <button style="" class="btn btn-sm btn-primary" type="submit" id="append" name="append">
                        Add</button> -->
                        </div>
                         <form action="javascript:void(0)" method="POST" enctype="multipart/form-data" id="formId">
                           @csrf
                             <div class="row">
                                <div class="col-md-12">
                                        <div class="form-group">
                                          <label for="name">Exercise Level 1<span style="color:red">*</span></label> 
                                          <select name="exercise_id" class="form-control">
                                           @foreach($exercise as $key => $val) 
                                            <option value="{{ $val->id }}">{{  $val->name }}</option>  
                                           @endforeach 
                                          </select>    
                                        </div>
                                </div>
          
                              

                                <div class="col-md-12">
                                          <div class="inc">
                                                <div class="controls row">
                                                    <div class="form-group col-md-4">
                                                        <label for="name">Name<span style="color:red">*</span></label> 
                                                        <input type="text" class="form-control" value="{{ old('name.0') }}" name="name[]"/> 
                                                        <input type="hidden" id="tt_fields" value="{{ old('tal_f') }}" class="form-control" name="tal_f" /> 
                                                    </div>

                                                    <div class="form-group col-md-3">
                                                    <!-- <button class="btn btn-primary toolcls" data-clipboard-text="1">Click me</button> -->
                                                      <label for="video">Video<span style="color:red">*</span></label> 
                                                      <input type="file" accept="video/*" class="form-control" name="videos[]" />
                                                    </div>    

                                                    <div class="form-group col-md-4">
                                                      <label for="description">Description<span style="color:red">*</span></label> 
                                                      <textarea type="text" class="form-control" name="description[]"></textarea>
                                                    </div>    
                                                </div>
                                          </div>
                                </div>

                            


                             </div>
                                <button type="reset" class="btn btn-sm btn-danger">Reset</button> 
                                <button class="btn btn-sm btn-primary" id="send_data">Submit</button> 
                           </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('admin.includes.footer')
</div>

@endsection


@section('custom_css')

<style>
.fade-in .btn-block {
    display: block;
    width: 100%;
    text-align: right;
}
.remove_this.btn.btn-danger {
    margin-top:32px;
}
</style>
@endsection

@section('custom_js')
<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.5.10/clipboard.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet"/> -->

<script type="text/javascript">
      var total_f  = 0;
     $( function() {
       // CKEDITOR.replace( 'description' );


      $("#append").click( function(e) {
        ++total_f; 
        $("#tt_fields").val(total_f);
      e.preventDefault();
      $(".inc").append('<div class="controls row">\
         <div class="form-group col-md-4"> <label for="name">Name<span style="color:red">*</span></label> <input class="form-control" type="text" value="{{ old('".name."') }}" name="name[]"></div>\
         <div class="form-group col-md-3"> <label for="video">Video<span style="color:red">*</span></label> <input class="form-control" type="file" value="{{ old('".videos."') }}" accept="video/*" name="videos[]"></div>\
         <div class="form-group col-md-4"> <label for="description">Description<span style="color:red">*</span></label> <textarea class="form-control" name="description[]"></textarea></div>\
         <div class="col-md-1 mb-4 text-right"><a href="#" class="remove_this btn btn-danger"><i class="fal fa-times"></i></a></div>\
          <br>\
          <br>\
      </div>');
      return false;
      });

      $(document).on('click', '.remove_this', function() {
        $(this).parent().parent().remove();
        return false;
      });


      $('#send_data').click(function(e){
        e.preventDefault();
        /*Ajax Request Header setup*/
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

   //$('#send_data').html('Sending..');
  // console.log($('#formId').serialize());
   var formData  = new FormData($('#formId')[0]);
   
   /* Submit form data using ajax*/
   $.ajax({
      url: "{{ route('sub-exercise.store') }}",
      method: 'post',
     // dataType: 'JSON',
      data: formData,
      cache:false,
      contentType: false,
      processData: false,
      success: function(response){
            var finallymsg ='';
            if(response.status=='success')
            {
                finallymsg = response.msg;
                 document.getElementById("formId").reset(); 
            }
            else
            {
                $.each(response.msg, function( key, value )
                 {
                    finallymsg += value+'<br>';
                });
            }
           
        
            (function () {
                Lobibox.notify(response.status, {
                    rounded: false,
                    delay: 4000,
                    delayIndicator: true,
                    msg: finallymsg
                });
            })();
        
            if(response.status=='success')
            {
                setTimeout(function(){
                 window.location.href = "{{ route('sub-exercise.index') }}"
                },3000); 
            }
            
    
      }});
   });

  });



    // Tooltip

// $('.toolcls').tooltip({
//   trigger: 'click',
//   placement: 'bottom'
// });

// function setTooltip(message) {
//   $('.toolcls').tooltip('hide')
//     .attr('data-original-title', message)
//     .tooltip('show');
// }

// function hideTooltip() {
//   setTimeout(function() {
//     $('.toolcls').tooltip('hide');
//   }, 5000);
// }

// // Clipboard

// var clipboard = new Clipboard('.toolcls');

// clipboard.on('success', function(e) {
//   setTooltip('only mp4 and avl format are allow and video is not then 10 MB');
//   hideTooltip();
// });

// clipboard.on('error', function(e) {
//   setTooltip('Failed!');
//   hideTooltip();
// });
</script>

@endsection