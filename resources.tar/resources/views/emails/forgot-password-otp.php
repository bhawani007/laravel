<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<title>::FitnessApp::</title>
<style>
  h1, h2, h3, h4, h5, h6, p {
    margin: 0;
    padding-bottom: 10px;
  }
  p {
    font-size: 18px;
    color: #2c1f23;
  }
  @font-face {
  font-family: 'Aileron-Black';
  src: url('./fonts/Aileron-Black.eot?#iefix') format('embedded-opentype'),  
  url('./fonts/Aileron-Black.otf')  format('opentype'),
  url('./fonts/Aileron-Black.woff') format('woff'), 
  url('./fonts/Aileron-Black.ttf')  format('truetype'), 
  url('./fonts/Aileron-Black.svg#Aileron-Black') format('svg');
  font-weight: normal;
  font-style: normal;
}
@font-face {
  font-family: 'Aileron-Bold';
  src: url('./fonts/Aileron-Bold.eot?#iefix') format('embedded-opentype'),  
  url('./fonts/Aileron-Bold.otf')  format('opentype'),
  url('./fonts/Aileron-Bold.woff') format('woff'), 
  url('./fonts/Aileron-Bold.ttf')  format('truetype'), 
  url('./fonts/Aileron-Bold.svg#Aileron-Bold') format('svg');
  font-weight: normal;
  font-style: normal;  
}
@font-face {
  font-family: 'Aileron-Italic';
  src: url('Aileron-Italic.eot?#iefix') format('embedded-opentype'),  
  url('./fonts/Aileron-Italic.otf')  format('opentype'),
  url('./fonts/Aileron-Italic.woff') format('woff'), 
  url('./fonts/Aileron-Italic.ttf')  format('truetype'), 
  url('./fonts/Aileron-Italic.svg#Aileron-Italic') format('svg');
  font-weight: normal;
  font-style: normal;
}
@font-face {
  font-family: 'Aileron-Light';
  src: url('./fonts/Aileron-Light.eot?#iefix') format('embedded-opentype'), 
  url('./fonts/Aileron-Light.otf')  format('opentype'),
  url('./fonts/Aileron-Light.woff') format('woff'), 
  url('./fonts/Aileron-Light.ttf')  format('truetype'), 
  url('./fonts/Aileron-Light.svg#Aileron-Light') format('svg');
  font-weight: normal;
  font-style: normal;
}
@font-face {
  font-family: 'Aileron-Regular';
  src: url('./fonts/Aileron-Regular.eot?#iefix') format('embedded-opentype'),  
  url('./fonts/Aileron-Regular.otf')  format('opentype'),
 url('./fonts/Aileron-Regular.woff') format('woff'), 
 url('./fonts/Aileron-Regular.ttf')  format('truetype'), 
 url('./fonts/Aileron-Regular.svg#Aileron-Regular') format('svg');
  font-weight: normal;
  font-style: normal;
}
@font-face {
  font-family: 'Aileron-SemiBold';
  src: url('./fonts/Aileron-SemiBold.eot?#iefix') format('embedded-opentype'),  
  url('./fonts/Aileron-SemiBold.otf')  format('opentype'),
 url('./fonts/Aileron-SemiBold.woff') format('woff'), 
 url('./fonts/Aileron-SemiBold.ttf')  format('truetype'), 
 url('./fonts/Aileron-SemiBold.svg#Aileron-SemiBold') format('svg');
}
</style>
</head>
<body style="margin:0px; padding:0px; font-family: 'Aileron-Regular'; color: #515151;" bgcolor="#f8f8f8">
  <table width="600" border="0" cellspacing="0" cellpadding="0" style="margin: 0 auto; background-color: #fff;">
    <tbody>
      <!-- <tr>
        <td>
          <table width="570" border="0" cellspacing="0" cellpadding="0" style="margin: 0 auto; padding: 25px 0;">
            <tbody>
              <tr>
                <td align="center">
                  <img src="/assets/frontend/images/logo.png" width="200" alt="Logo">
                </td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr> -->
      <tr>
        <td>
          <table width="600" border="0" cellspacing="0" cellpadding="0" style="margin: 0 auto; border: 1px solid #c4c4c4; border-bottom: none; background-color: #efefef; padding: 35px 0;">
            <tbody>
              <tr>
                <td>
                  <h2 style="color: #e61e25; font-size: 25px; text-align: center; padding-bottom: 0; text-transform: capitalize;">Forgot password for OTP</h2>           
                </td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
      <tr>
        <td>
          <table width="600" border="0" cellspacing="0" cellpadding="0" style="border: 1px solid #c4c4c4; border-top: none; border-bottom: none; margin: 0 auto; background-color: #fff; padding: 30px 0 20px;">
            <tbody>
              <tr>
                <td>
                  <table width="540" border="0" cellspacing="0" cellpadding="0" style="margin: 0 auto; ">
                    <tbody>
                      <tr>
                        <td>
                          <span style="font-size: 16px; padding-bottom: 10px; display: inline-block;">Hello <?php echo $user['name'];?>,</span>
                          <p style="padding-bottom: 15px;font-size: 16px; color: #000;"><strong>To enhance your information.</strong></p>
                          <p style="padding-bottom: 10px;font-size: 16px; color: #515151;"><strong>Email</strong>   :-<?php echo $user['email'];?></p>
                          <p style="padding-bottom: 10px;font-size: 16px; color: #515151;"><strong>TOP</strong>:-<?php echo $user['otp'];?> </p>
                         
                        </td>
                      </tr>
                     
                      <tr>
                        <td style="padding-top: 35px;">
                          <p style="padding-bottom: 0;font-size: 16px; color: #515151;">From,</p>
                          <p style="padding-bottom: 10px;font-size: 16px; color: #000;"><strong>The team at FitnessApp</strong></p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
    </tbody>
  </table>
</body>
</html>