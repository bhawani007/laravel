<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ChangeColumnsUserProfileTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('user_profiles', function (Blueprint $table) {
            $table->bigInteger('weight_goal')->change();
            //$table->renameColumn('weight_goal', 'weight_goal_id');
            $table->bigInteger('exercise_routine_id')->unsigned();
            $table->bigInteger('food_habit_id')->unsigned();
            //$table->foreign('weight_goal_id')->references('id')->on('goals')->onupdate('cascade')->ondelete('cascade');
            $table->foreign('exercise_routine_id')->references('id')->on('goals')->onupdate('cascade')->ondelete('cascade');
            $table->foreign('food_habit_id')->references('id')->on('goals')->onupdate('cascade')->ondelete('cascade');
            
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('user_profiles', function (Blueprint $table) {
            //
        });
    }
}
