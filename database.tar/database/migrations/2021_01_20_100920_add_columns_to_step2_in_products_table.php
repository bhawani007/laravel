<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsToStep2InProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('saturated_fat',255)->nullable();
            $table->string('trans_fat',255)->nullable();
            $table->string('cholesterol',255)->nullable();
            $table->string('total_carbohydrates')->nullable();
            $table->string('dietary_fibres',255)->nullable();
            $table->string('total_sugars',255)->nullable();
            $table->string('added_sugars',255)->nullable();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('products', function (Blueprint $table) {
            // $table->dropColumn('saturated_fat')->nullable()->after('image');
            // $table->dropColumn('trans_fat')->nullable()->after('saturated_fat');
            // $table->dropColumn('cholesterol')->nullable()->after('trans_fat');
            // $table->dropColumn('total_carbohydrates')->nullable()->after('cholesterol');
            // $table->dropColumn('dietary_fibres')->nullable()->after('total_carbohydrates');
            // $table->dropColumn('total_sugars')->nullable()->after('dietary_fibres');
            // $table->dropColumn('added_sugars')->nullable()->after('total_sugars');
        });
    }
}
