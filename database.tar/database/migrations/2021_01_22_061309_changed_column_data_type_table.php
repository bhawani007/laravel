<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ChangedColumnDataTypeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('name','191')->change();
            $table->decimal('total_fat', 9,2)->change();
            $table->string('barcode','255')->change();
            $table->decimal('saturated_fat', 9,2)->change();
            $table->decimal('trans_fat', 9,2)->change();
            $table->decimal('cholesterol', 9,2)->change();
            $table->decimal('sodium', 9,2)->change();
            $table->decimal('total_carbohydrates', 9,2)->change();
            $table->decimal('dietary_fibres', 9,2)->change();
            $table->decimal('total_sugars', 9,2)->change();
            $table->decimal('added_sugars', 9,2)->change();
            $table->decimal('protein', 9,2)->change();
            $table->decimal('vitamin_d', 9,2)->change();
            $table->decimal('calcium', 9,2)->change();
            $table->decimal('vitamin_c', 9,2)->change();
            $table->decimal('iron', 9,2)->change();
            $table->decimal('potassium', 9,2)->change();
            $table->integer('daily_value')->change();
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('products', function (Blueprint $table) {
            //
        });
    }
}
