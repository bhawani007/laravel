<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsInUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
           // $table->string('username',191)->after('name')->nullable();
           // $table->string('google_id',191)->after('email')->nullable();
           // $table->string('facebook_id',191)->after('google_id')->nullable();
           // $table->string('otp',10)->after('facebook_id')->nullable();
           // $table->enum('status', ['0', '1'])->default('1')->comment('0=>Inactive,1=>Active')->after('otp')->nullable();
           // $table->enum('device_type', ['1', '2'])->comment('1=>Android,2=>IOS')->after('status')->nullable();
         //   $table->string('device_token')->after('device_type')->nullable();
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
           // $table->dropColumn('username');
           // $table->dropColumn('google_id');
           // $table->dropColumn('facebook_id');
           // $table->dropColumn('otp');
           // $table->dropColumn('status');
           // $table->dropColumn('device_type');
           // $table->dropColumn('device_token');
        });
    }
}
