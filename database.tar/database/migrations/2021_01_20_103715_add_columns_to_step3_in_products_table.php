<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsToStep3InProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('protein',255)->nullable();
            $table->string('vitamin_d',255)->nullable();
            $table->string('calcium',255)->nullable();
            $table->string('iron')->nullable();
            $table->string('vitamin_c',255)->nullable();
            $table->string('potassium',255)->nullable();
            $table->string('daily_value',255)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('products', function (Blueprint $table) {
            // $table->dropColumn('protein')->nullable();
            // $table->dropColumn('vitamin_d')->nullable();
            // $table->dropColumn('calcium')->nullable();
            // $table->dropColumn('iron')->nullable();
            // $table->dropColumn('vitamin_c')->nullable();
            // $table->dropColumn('potassium')->nullable();
            // $table->dropColumn('daily_value')->nullable();
        });
    }
}
