<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddAnotherColumnsUnitProductTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('total_fat_unit')->after('total_fat')->nullable();
            $table->string('saturated_fat_unit')->after('saturated_fat')->nullable();
            $table->string('trans_fats_unit')->after('trans_fat')->nullable();
            $table->string('cholestrol_unit')->after('cholesterol')->nullable();
            $table->string('sodium_unit')->after('sodium')->nullable();
            $table->string('total_carbohydrates_unit')->after('total_carbohydrates')->nullable();
            $table->string('dietry_fibres_unit')->after('dietary_fibres')->nullable();
            $table->string('total_sugars_unit')->after('total_sugars')->nullable();
            $table->string('protein_unit')->after('protein')->nullable();
            $table->string('potassium_unit')->after('potassium')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('products', function (Blueprint $table) {
            //
        });
    }
}
