<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator,Mail;
use App\Models\Goal;

class RoutingController extends Controller
{
    public function __construct(Goal $Goal)
    {
       $this->goals = $Goal;
    } 

    public function index()
    {
        $info = $this->goals::where('type','2')->get();
        return view('admin.goal-routines.index',compact('info')); 
    }

    public function create()
    {
        return view('admin.goal-routines.add');
    }

    public function store(Request $request)
    {
       $validator = Validator::make($request->all(), [
         'name'          => 'required',
         'type'          => 'required',
        // 'features'      => 'required' 
       ]);

       if($validator->fails())
       {
           return back()->withErrors($validator)->withInput();
       }

       try{
       
        $res = $this->goals->add($request->all());
        if($res['status'])
        return redirect()->route('goal-routines.index')->with('success','Exercise Routine added successfully');
        else
        return redirect()->back()->with('erros','Something went wrong');
       }catch(\Throwable $th){
           return redirect()->back()->with('erros','Something went wrong');
       }
    }

    public function edit($id)
    {  
       $info = $this->goals::find($id);
       return view('admin.goal-routines.edit')->with('info', $info);;
    }

    public function update(request $request, $id)
    {
         $validator = Validator::make($request->all(), [
          'name'       => 'required|max:255'
         ]);

         if($validator->fails())
         {
           return back()->withErrors($validator)->withInput();
         }

         try{

          $res = $this->goals->updateGoal($request->all(), $id);
          if($res['status'])
          return redirect()->route('goal-routines.index')->with('success','Exercise Routine updated successfully');
          else
          return back()->wtih('error','Something went wrong');

         }catch(\Throwable $th){
           return back()->with('error','Something went wrong'); 
         }

    }

    public function delete($id)
    {
      $res = $this->goals::destroy($id);
      if($res)
      return redirect()->route('goal-routines.index')->with('success','Exercise Routine deleted successfully');
      else
      return back()->wtih('error','Something went wrong');
    }

    public function show($id)
    { 
      $info           =      $this->goals::find($id);
      return view('admin.goal-routines.view')->with(compact('info'));
    }
}
