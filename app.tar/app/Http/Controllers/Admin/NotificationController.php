<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Notification;

class NotificationController extends Controller
{
    public function __construct(Notification $notification)
    {
       $this->notification   =  $notification;
    }

    public function index()
    {
          $all  =  $this->notification::with('senderDetail','receiverDetail')->get();
          return view('admin.notifications',compact('all'));

    }

    public function destroy($id)
    {
        $obj   =  $this->notification::find($id);
        $obj->destroy($id);

        return back()->with('success','Notification deleted successfully.');
    }
}
