<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Exercise;
use App\Models\SubExercise;
use Validator;

class ExerciseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function __construct(Exercise $exercise,SubExercise $subexercise)
    {   
        $this->exercise           =    $exercise;
        $this->subexercise        =    $subexercise;
    }


    public function index()
    {   
        $info    = $this->exercise::orderBy('id', 'desc')->get();
        return view('admin.exercises.index',['info' =>$info]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.exercises.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {  
        $validator          =    Validator::make($request->all(), [
            //'video'       =>    'required|mimes:mp4,mov,ogg,qt',
            'name'          =>    'required|max:255',
            'description'   =>    'required'
        ]);


        if($validator->fails())
        {
            return back()->withErrors($validator)->withInput();
        }
       
        try{
            $res   =  $this->exercise->add($request->all());
            if($res['status'])
            return redirect()->route('exercises.index')->with('success','Exercise added successfully');
            else
            return back()->with('error',"Something went wrong");
        
        }catch(\Throwable $th){
            dd($th);
           return back()->with('error','Something went wrong');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $execisedetail       =  $this->exercise::find($id);
        $info                =  $this->subexercise::where('exercise_id',$id)->get();
        // return view('admin.exercises.view',['info' => $info]);
          return view('admin.exercises.view',['info' => $info,'execisedetail' => $execisedetail]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $info  =  $this->exercise::find($id);
        return view('admin.exercises.edit')->with('info',$info);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {    
        $validator    =   Validator::make($request->all(),
        [
            //'video'         =>  'required|mimes:mp4,mov,ogg,qt',
            'name'            =>  'required|max:255',
            'description'     =>  'required'
        ]);


        if($validator->fails())
        {
            return back()->withErrors($validator)->withInput();
        }

        try{
          $res   =  $this->exercise->updateExer($request->all(), $id);
          if($res['status'])
          return redirect()->route('exercises.index')->with('success','Exercise updated successfully');
          else
          return back()->with('error','Something went wrong');   
       
          }catch(\Throwable $th){
           return redirect()->back()->with('error','Something went wrong'); 
         }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try{

            $obj     =  $this->exercise::find($id);
            $obj->destroy($id);
            return back()->with('success','Exercise deleted successfully');

           }catch(\Throwable $th)
           {
            return redirect()->route('exercise.index')->with('error','Something went wrong');
           }
    }
}
