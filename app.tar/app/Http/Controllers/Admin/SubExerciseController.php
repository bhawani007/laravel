<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SubExercise;
use App\Models\Exercise;
use Validator,Response,Session;

class SubExerciseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct(SubExercise $subexercise, Exercise $exercise)
    {
        $this->subexercise        =    $subexercise;
        $this->exercise           =    $exercise;
    } 

    public function index()
    {
        $exerlist     =   $this->exercise::all();
        $subexer      =   $this->subexercise::with('exercise')->orderBy('exercise_id')->get();
        return view('admin.subexercises.index',compact('exerlist', 'subexer'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       $exercise   =  $this->exercise::all();
       return view('admin.subexercises.add',compact('exercise'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         // dd($request->all());
        //   $validator    =   Validator::make($request->all(),
        //   [
        //       'exercise_id'        =>  'required',
        //       'name.*'             =>  'required',
        //       'videos.*'           =>  'required',
        //       'description.*'      =>  'required'
        //   ]);


        $input = $request->all();
        $rules = [];
        

        foreach($input['name'] as $key => $val)
        {   
            $rules['name.'.$key]          =  'required';
            $rules['videos.'.$key]        =  'required';
            $rules['description.'.$key]   =  'required';
        }

        $rules['exercise_id'] = 'required|integer';


        

        //$rules['description'] = 'required|string';

        //dd($rules);

        $validator = Validator::make($input, $rules);
        //dd($validator->errors()->all());


         if($validator->fails())
         {    
             //return redirect()->back()->withErrors($validator)->withInput();
            return response()->json(['status'=>'error','msg'=>$validator->errors()->all()]);
         } 

         try{
                $res  =  $this->subexercise->add($request->all());
            
                if($res['status'])
                {
                    return response()->json(['status'=>'success','msg'=>'Sub exercise added successfully']);
                }
                else{
                    return response()->json(['status'=>'error','msg'=>'Something went wrong']);
                }

            }catch(\Throwable $th){
               return response()->json(['status'=>'error','msg'=>'Something went wrong']);
             //return redirect()->back()->with('error','Something went wrong');
         }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $info   =  $this->subexercise::with('exercise')->first();
        return view('admin.subexercises.view',compact('info'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $exercisedetail    =   $this->exercise::all();
      $info              =  $this->subexercise::where('id',$id)->get();
      return view('admin.subexercises.edit',['info' => $info,'exercise' => $exercisedetail]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
                 
                $input  = $request->all();
                $rules  = [];

             
                foreach($input['name'] as $key => $val)
                {
                    $rules['name.'.$key]          =   'required';
                    $rules['videos.'.$key]         =   'required';
                    $rules['description.'.$key]   =   'required';  

                
                }

                $rules['exercise_id']         =   'required|integer';


                $validator      =     Validator::make($input, $rules);
            // dd($validator->errors()->all());

                if($validator->fails())
                {
                    return response()->json(['status'=>'error','msg'=>$validator->errors()->all()]);
                }


            try{
                 $res  =  $this->subexercise->updateData($input);
                 if($res['status'])
                 {
                   return response()->json(['status'=>'success','msg'=>'Sub Exercise updated successfully']);
                 }
                 else
                 {
                   return response()->json(['status'=>'error','msg'=>'Something went wrong']);
                 }

               }catch(\Throwable $th){
                
                 return response()->json(['status'=>'error','msg'=>$th]);
               }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {   
        try{

            $obj     =  $this->subexercise::find($id);
            $obj->destroy($id);
            return back()->with('success','Sub Exercise deleted successfully');

           }catch(\Throwable $th)
           {
            return redirect()->route('sub-exercise.index')->with('error','Something went wrong');
           }

    }
}
