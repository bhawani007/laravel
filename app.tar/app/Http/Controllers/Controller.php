<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Notification;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;



    /*
    =============================================================================
    |           -----PUSH NOTIFICATION USING FIREBASE-----
    ============================================================================= 
    */ 

    public function sendNotification($device_token, $dataArr, $payload)
    {
        $url = 'https://fcm.googleapis.com/fcm/send'; // Google URL
        $message = $dataArr['message'];
        $title = 'Fitness App';
        // prepare the bundle
        $msg = array('body'=>$message, 'title'=>$title, 'message'=>$message, 'payload'=>$payload);
        $fields = array( 
            "to" => $device_token,  
            "collapse_key" => "type_a",
            'notification' => $msg,
            "smallIcon"=> "new_icons",
            "android"=> array(
                "priority"=> "low",
                "title"=> "Andorid",
                "sound"=> "tone_goes_without_saying",
                "android_channel_id"=> "announcement",
                "channel_id"=> "announcement",
                "smallIcon"=> "new_icons",
                "notification"=> array(),
            ),
            "data"=> $msg,
        );
        $headers = array( 
            'Content-Type: application/json',
            'Authorization: key=AAAAP4u6PVI:APA91bEWx0iGiQT4_4RYXd5sW3eeQ3ThQwGfA2scuWWqrvObMs0OMiIpsPhBvcrXlW_oSJAJHw_qjq0ZDOeD1gI84Dd_5kLLJ1OM0XHwexvtdj5tsWftCLEb_dsQf0cZqFNQfZSUhati'
        );
        $data_string = json_encode($fields);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        $result = curl_exec($ch);
        return true;
    }

   //========================================Push Notification Class ends=============================================//    

    public function entryNotification($sender_id, $receiver_id, $type, $title, $payload, $dataArr)
    {
            //Save into Notifications table---------
            $notify  =  Notification::create([
                'sender_id'   => $sender_id,
                'receiver_id' => $receiver_id,
                'type'        => $type,
                'title'       => $title,
                'payload'     => json_encode($payload, true),
                'description' => json_encode($dataArr, true)
            ]); 
    } 



}
