<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Exports\ProductsExport;
use App\Imports\ProductsImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\Product;
use App\Models\ProductImage;
use Validator;

class ProductController extends Controller
{

    public function __construct(Product $product)
    {
       $this->product = $product;
    }

    public function index()
    {
        $listpro = $this->product::orderBy('id', 'desc')->get();
        return View('admin.product.index',compact('listpro'));   
    }

    public function add()
    {
        return view('admin.product.add');
    }

    public function store(request $request)
    {
        $validator = Validator::make($request->all(), [
            'name'                      => 'required|max:191|regex:/^[\pL\s\-]+$/u',
            'type'                      => 'required|integer',
            'calories'                  => 'required|numeric|between:0,9999999.99',
            'total_fat'                 => 'required|numeric|between:0,9999999.99',
            'sodium'                    => 'required|numeric|between:0,9999999.99',
            'barcode'                   => 'required',
            'barcode_type'              => 'required',
            'serving_bowl'              => 'nullable|numeric|between:0,9999999.99',
            'serving_unit'              => 'nullable',
            'total_fat_unit'            => 'nullable|alpha',
            'sodium_unit'               => 'nullable|alpha',
            'saturated_fat'             => 'nullable|numeric|between:0,9999999.99',
            'saturated_fat_unit'        => 'nullable|alpha',
            'trans_fat'                 => 'nullable|numeric|between:0,9999999.99',
            'trans_fats_unit'           => 'nullable|alpha',
            'cholesterol'               => 'nullable|numeric|between:0,9999999.99',
            'cholestrol_unit'           => 'nullable|alpha',
            'total_carbohydrates'       => 'nullable|numeric|between:0,9999999.99',
            'total_carbohydrates_unit'  => 'nullable|alpha',
            'dietry_fibres'             => 'nullable|numeric|between:0,9999999.99',
            'dietry_fibres_unit'        => 'nullable|alpha',
            'total_sugars'              => 'nullable|numeric|between:0,9999999.99',
            'total_sugars_unit'         => 'nullable|alpha',
            'added_sugars'              => 'nullable|numeric|between:0,9999999.99',
            'added_sugars_unit'         => 'nullable|alpha',
            'protein'                   => 'nullable|numeric|between:0,9999999.99',
            'protein_unit'              => 'nullable|alpha',
            'vitamin_d'                 => 'nullable|numeric|between:0,9999999.99',
            'iron'                      => 'nullable|numeric|between:0,9999999.99',
            'vitamin_c'                 => 'nullable|numeric|between:0,9999999.99',
            'potassium'                 => 'nullable|numeric|between:0,9999999.99',
            'potassium_unit'            => 'nullable|alpha',
            'daily_value'               => 'nullable|numeric|between:0,9999999.99',
            'calcium'                   => 'nullable|numeric|between:0,9999999.99',
        ]);

        if($validator->fails())
        {
          return back()->withErrors($validator)->withInput();
        }

        try{

            $fileexist = 0;
            if($request->hasFile('image'))
            {
             $fileexist = 1;
            }

            $res = $this->product->Step1($request->all(), $fileexist);
            
            if($res['status'])
            {
              return redirect()->route('product.index')->with('success','Product added successfully');
            }
            else
            {
              return back()->with('error','Something went wrong');
            }

        }
        catch(\Throwable $th)
        { dd($th); 
          return back()->with('error','Something went wrong');
        }

    }

    public function importData()
    {
        return View('admin.product.import');
    }

    public function export() 
    {
        $date = date('Y-m-d i:s');
        return Excel::download(new ProductsExport, 'product-'.$date.'.xlsx');
    }

    public function import(request $request) 
    {
        $input = $request->all();
       
        $validator = Validator::make($input, [
            'file'          => 'required',
        ]);

        if($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        try{
            $data = Excel::toArray(new ProductsImport,request()->file('file'));
            

            foreach ($data as $key => $row1) 
            {   
               foreach ($row1 as $key => $row) 
               { 
            
                $obj =  Product::where('barcode', $row['barcode'])->first();
                if(!$obj)
                {
                    $obj = new Product;
                }

                $obj->name                   	= $row['product_name'];
                $obj->type                 		= $row['type'];
                $obj->barcode             		= $row['barcode'];
                $obj->barcode_type             	= $row['barcode_type'];
                $obj->serving_bowl              = $row['serving_bowl'];
                $obj->serving_unit          	= $row['serving_unit'];
                $obj->calories              	= $row['calories']; 
                $obj->total_fat         		= $row['total_fat'];
                $obj->total_fat_unit            = $row['fat_unit'];
                $obj->sodium          		 	= $row['sodium'];
                $obj->sodium_unit  			 	= $row['sodium_unit'];
                $obj->saturated_fat             = $row['saturated_fat'];
                $obj->saturated_fat_unit        = $row['saturated_fat_unit'];
                $obj->trans_fat                 = $row['trans_fats'];	
                $obj->trans_fats_unit           = $row['trans_fats_unit'];	
                $obj->cholesterol               = $row['cholestrol'];	
                $obj->cholestrol_unit           = $row['cholestrol_unit'];	
                $obj->total_carbohydrates       = $row['total_carbohydrates'];	
                $obj->total_carbohydrates_unit  = $row['total_carbohydrates_unit'];
                $obj->dietry_fibres             = $row['dietry_fibres'];
                $obj->dietry_fibres_unit        = $row['dietry_fibres_unit'];
                $obj->total_sugars              = $row['total_sugars'];
                $obj->total_sugars_unit         = $row['total_sugars_unit'];
                $obj->added_sugars              = $row['added_sugars'];
                $obj->added_sugars_unit         = $row['added_sugars_unit'];
                $obj->protein                   = $row['protein'];
                $obj->protein_unit              = $row['protein_unit'];
                $obj->vitamin_d                 = $row['vitamin_d'];
                $obj->calcium                   = $row['calcium'];
                $obj->iron            		    = $row['iron'];
                $obj->vitamin_c          		= $row['vitamin_c'];
                $obj->potassium          		= $row['potassium'];
                $obj->potassium_unit            = $row['potassium_unit'];
                $obj->daily_value          		= $row['daily_value_dv'];
                $obj->save();
            }
        }

          // Excel::import(new ProductsImport,request()->file('file'));
         return redirect()->route('product.index')->with("success","Product imported successfully");

        }catch(\throwable $th){
            return back()->with("error","Something went wrong");
        }

    }


    public function show($id)
    {      
           $val = $this->product::find($id);          
           return view('admin.product.view',compact('val'));
    }

    public function destroy($id = null)
	{
        try{
			$this->product::where('id',$id)->delete();
            return back()->with('success','Product deleted successfully');
        }catch(\Throwable $th){
            return back()->with('error', 'Something went wrong');
        }
    }
    
    public function edit($id)
    {  
       $pro = $this->product::find($id); 
       return view('admin.product.edit',compact('pro'));
    }

    public function update(request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name'                      => 'required|max:191|regex:/^[\pL\s\-]+$/u',
            'type'                      => 'required|integer',
            'calories'                  => 'required|numeric|between:0,9999999.99',
            'total_fat'                 => 'required|numeric|between:0,9999999.99',
            'sodium'                    => 'required|numeric|between:0,9999999.99',
            'barcode'                   => 'required',
            'barcode_type'              => 'required',
            'serving_bowl'              => 'nullable|numeric|between:0,9999999.99',
            'serving_unit'              => 'nullable',
            'total_fat_unit'            => 'nullable|alpha',
            'sodium_unit'               => 'nullable|alpha',
            'saturated_fat'             => 'nullable|numeric|between:0,9999999.99',
            'saturated_fat_unit'        => 'nullable|alpha',
            'trans_fat'                 => 'nullable|numeric|between:0,9999999.99',
            'trans_fats_unit'           => 'nullable|alpha',
            'cholesterol'               => 'nullable|numeric|between:0,9999999.99',
            'cholestrol_unit'           => 'nullable|alpha',
            'total_carbohydrates'       => 'nullable|numeric|between:0,9999999.99',
            'total_carbohydrates_unit'  => 'nullable|alpha',
            'dietry_fibres'             => 'nullable|numeric|between:0,9999999.99',
            'dietry_fibres_unit'        => 'nullable|alpha',
            'total_sugars'              => 'nullable|numeric|between:0,9999999.99',
            'total_sugars_unit'         => 'nullable|alpha',
            'added_sugars'              => 'nullable|numeric|between:0,9999999.99',
            'added_sugars_unit'         => 'nullable|alpha',
            'protein'                   => 'nullable|numeric|between:0,9999999.99',
            'protein_unit'              => 'nullable|alpha',
            'vitamin_d'                 => 'nullable|numeric|between:0,9999999.99',
            'iron'                      => 'nullable|numeric|between:0,9999999.99',
            'vitamin_c'                 => 'nullable|numeric|between:0,9999999.99',
            'potassium'                 => 'nullable|numeric|between:0,9999999.99',
            'potassium_unit'            => 'nullable|alpha',
            'daily_value'               => 'nullable|numeric|between:0,9999999.99',
            'calcium'                   => 'nullable|numeric|between:0,9999999.99',
            'image.*'                   => 'nullable|image|mimes:jpeg,png,jpg,gif,svg',
        ]);


        if($validator->fails()){
            return back()->withErrors($validator)->withInput();    
        }

        try{
            $fileexist = 0;
            if($request->hasFile('image'))
            {
             $fileexist = 1;
            }

         $res  = $this->product->Step1($request->all(), $fileexist);
         if($res['status']){
          return redirect()->route('product.index')->with("success","Product updated successfully");
         }
         else{
          return back()->with("error","Something went wrong");
         }

        }catch(\Throwable $th){
            return back()->with("error","Something went wrong");
        }
    }


    public function barcode()
	{
	    return view('admin.product.barcode');
	}
}
