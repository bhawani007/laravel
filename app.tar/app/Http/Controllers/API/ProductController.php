<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use App\Models\Product;
use Validator;

class ProductController extends BaseController
{

    public function __construct(Product $product){
        $this->product = $product;
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        $products = Product::all();
        return $this->sendResponse(200, 'Products retrieved successfully.',$products);
    }


     /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function storestep1(Request $request)
    {
        $input = $request->all();
    
        $validator = Validator::make($input, [
            'name'                      => 'required|regex:/^[\pL\s\-]+$/u',
            'type'                      => 'required|integer',
            'calories'                  => 'required|numeric|between:0,9999999.99',
            'total_fat'                 => 'required|numeric|between:0,9999999.99',
            'sodium'                    => 'required|numeric|between:0,9999999.99',
            'barcode'                   => 'required',
            'barcode_type'              => 'required',
            'serving_bowl'              => 'nullable|numeric|between:0,9999999.99',
            'serving_unit'              => 'nullable',
            'total_fat_unit'            => 'nullable|alpha',
            'sodium_unit'               => 'nullable|alpha',
            'saturated_fat'             => 'nullable|numeric|between:0,9999999.99',
            'saturated_fat_unit'        => 'nullable|alpha',
            'trans_fat'                 => 'nullable|numeric|between:0,9999999.99',
            'trans_fats_unit'           => 'nullable|alpha',
            'cholesterol'               => 'nullable|numeric|between:0,9999999.99',
            'cholestrol_unit'           => 'nullable|alpha',
            'total_carbohydrates'       => 'nullable|numeric|between:0,9999999.99',
            'total_carbohydrates_unit'  => 'nullable|alpha',
            'dietry_fibres'             => 'nullable|numeric|between:0,9999999.99',
            'dietry_fibres_unit'        => 'nullable|alpha',
            'total_sugars'              => 'nullable|numeric|between:0,9999999.99',
            'total_sugars_unit'         => 'nullable|alpha',
            'added_sugars'              => 'nullable|numeric|between:0,9999999.99',
            'added_sugars_unit'         => 'nullable|alpha',
            'protein'                   => 'nullable|numeric|between:0,9999999.99',
            'protein_unit'              => 'nullable|alpha',
            'vitamin_d'                 => 'nullable|numeric|between:0,9999999.99',
            'iron'                      => 'nullable|numeric|between:0,9999999.99',
            'vitamin_c'                 => 'nullable|numeric|between:0,9999999.99',
            'potassium'                 => 'nullable|numeric|between:0,9999999.99',
            'potassium_unit'            => 'nullable|alpha',
            'daily_value'               => 'nullable|numeric|between:0,9999999.99',
            'calcium'                   => 'nullable|numeric|between:0,9999999.99',
            'added_by'                  => 'nullable|numeric',
            //'barcode'   => 'required|unique:products,barcode',
            //'image'    => 'required',
            //'image.*'  => 'image|mimes:jpeg,png,jpg,gif,svg',
        ]);


        if($validator->fails()){
            return $this->sendResponse(404, $validator->messages()->first(),$request->all());       
        }

        try {
            
             $fileexist = 0;
            if($request->hasFile('image'))
            {
             $fileexist = 1;
            }

           $res  = $this->product->Step1($input, $fileexist);
           if($res['status'])
            return $this->sendResponse(200,"Product added successfully",$res['data']);
           else
            return $this->sendResponse(500,"Something went wrong",$input);
            
        }catch(\Throwable $th){
            return $this->sendResponse(500, "Something went wrong",$th);       
        }

    }
    
    // public function storestep2(Request $request, $id)
    // {
    //     $input = $request->all();

    //     try {
    //        $res  = $this->product->Step2($input, $id);
    //        if($res['status'])
    //         return $this->sendResponse(200,"Product added successfully",$id);
    //        else
    //         return $this->sendResponse(500,"Something went wrong",$input);
            
    //     }catch(\Throwable $th){
    //         return $this->sendResponse(500, "Something went wrong",$th);       
    //     }

    // }

    // public function storestep3(Request $request, $id)
    // {
    //     $input = $request->all();

    //     $validator = Validator::make($input, [
    //         'protein'      => 'required',
    //         'vitamin_d'    => 'required',
    //         'calcium'      => 'required',
    //         'iron'         => 'required',
    //         'vitamin_c'    => 'required',
    //         'potassium'    => 'required',
    //         'daily_value'  => 'required'
    //     ]);

    //     if($validator->fails()){
    //         return $this->sendResponse(404, $validator->messages()->first(),$request->all());       
    //     }

    //     try {
    //        $res  = $this->product->Step3($input, $id);
    //        if($res['status'])
    //         return $this->sendResponse(200,"Product added successfully",$res['data']);
    //        else
    //         return $this->sendResponse(500,"Something went wrong",$input);
            
    //     }catch(\Throwable $th){
    //         return $this->sendResponse(500, "Something went wrong",$th);       
    //     }
    // }

   

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    // public function show($id)
    // {
    //     $product = Product::find($id);
    //     if (is_null($product)) {
    //         return $this->sendError('Product not found.');
    //     }
    //     return $this->sendResponse(new ProductResource($product), 'Product retrieved successfully.');

    // }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    // public function update(Request $request, Product $product)
    // {
    //     $input = $request->all();
    //     $validator = Validator::make($input, [
    //         'name' => 'required',
    //         'detail' => 'required'
    //     ]);

    //     if($validator->fails()){
    //         return $this->sendError('Validation Error.', $validator->errors());       
    //     }

   
    //     $product->name = $input['name'];
    //     $product->detail = $input['detail'];
    //     $product->save();

    //     return $this->sendResponse(new ProductResource($product), 'Product updated successfully.');

    // }

   

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function destroy(Product $product)
    // {
    //    $product->delete();
    //    return $this->sendResponse([], 'Product deleted successfully.');
    // }

}
