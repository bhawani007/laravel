<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use Redirect,Hash,Auth,Mail;

class UserController extends Controller
{


    public function index()
    {
        if(Auth::check()){
            return Redirect::to('/');
        }
        else{ 
            return view('admin.index');
        }
    }

    public function login(request $request)
    {   
        $validator = Validator::make($request->all(), [
            'email'    => 'required|email',
            'password' => 'required',
        ]);

        if($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        try{
            $input =  $request->all();
            $user =  ['email' => $request->email, 'password' => $request->password];

           if(Auth::attempt($user))
           {
            $userrole   =  Auth::user()->roles->pluck('name');
            
            if(isset($userrole[0]) && $userrole[0] == "admin"){
                return redirect()->route('dashboard');
            }else{
              
                Auth::logout();
                return redirect('/')->with("error","Credential not matched");
            }     
          }
          else
          {
            return redirect('/')->with("error","Credential not matched");   
          } 

        }catch(\e $th){
            return back()->with('error',"Something went wrong");
        }
      
    }


    public function dashboard()
    {
        return View('admin.dashboard');
    }
    public function register()
    {

    }

    public function logout()
    {
        Auth::logout();
		return Redirect::to('/');
    }

    public function forgotPassword()
    {
        if(Auth::check()){
            return Redirect::to('/');
        }
        else{ 
            return view('admin.guest-forgot-password');
        }
        
    }

    public function forgotPasswordData(request $request)
    {

       $validator       =  validator::make($request->all(),
       [
           'email'     =>  'required|email'
       ]);

       if($validator->fails())
       {
           return back()->withErrors($validator)->withInput();
       }

       try{
                  $obj   =  User::where('email',$request->email)->first(); 
              if($obj)
              {
                 $token                    =   md5($obj->email); 
                 $obj->remember_token      =   $token;
                 $obj->save();
                
                Mail::send('emails.rest-password', ['user' => $obj], function ($m) use ($obj) {
                    $m->from('admin@fitnessapp.com', 'Fitness App');

                    $m->to($obj->email)->subject('Reset Password');
                });    

               return back()->with('success','We have sent a rest password link.check your email adress'); 
              }else
              {
                return back()->with('error','Email address not found in our record');   
              }

       }
       catch(\Throwable $th){
           return back()->with('error','Something went wrong');
        }
    }


    public function resetPassword($token)
    {
        if(Auth::check()){
            return Redirect::to('/');
        }
        else{ 
            if($token){
                return view('admin.reset-password',compact('token'));
            }else{
                return redirect('/')->with('error','Something went wrong'); 
            }
        }   
    }


    public function resetPasswordData(request $request)
    {  
             $validator     =  Validator::make($request->all(),
             [
               'password'   => 'required|min:8|same:confirm_password'     
             ]); 

            if($validator->fails())
            {
                return back()->withErrors($validator)->withInput();
            }

            try{

                $obj      =    User::where('remember_token',$request->token)->first();
                if($obj)
                {
                    $obj->password          =   hash::make($request->password);
                    $obj->remember_token    =   '';
                    $obj->save();

                    return redirect()->route('login')->with('success','Your password reset successfully');
                 }else{
                    return back()->with('error','You already used this token.');  
                 }


            }catch(\Throwable $th){ 
            
                return redirect()->back()->with('error','Something went wrong');
            }

    }


    public function profile()
    {
        $id       =  Auth::user()->id;
        $info     =  User::find($id);
        return view('admin.profile',compact('info'));
    }


   public function editProfile()
   {
        $id       =  Auth::user()->id;
        $info     =  User::find($id);
        return view('admin.profile-edit',compact('info'));
   }


   public function updateProfile(request $request)
   {
            $id          =  Auth::user()->id;

          $validator     =  Validator::make($request->all(),
          [
            'name'       => 'required',     
            'email'      => 'required|email|unique:users,email,'.$id,    
            'phone'      => 'required',     
            'address'    => 'required',     
            'about'      => 'required'
          ]); 

         if($validator->fails()) {
             return back()->withErrors($validator)->withInput();
         }

         try{
             $obj      =    User::find($id);
             if($obj)
             {
                if($request->hasFile('pic'))
                { 
                    $file               =   $request->file('pic');
                    $fname              =   time().'.'.$file->getClientOriginalExtension();
                    $destinationPath    =   public_path('/images');
                    $file->move($destinationPath, $fname);
                    $obj->profile_img   =    $fname;
    
                }

                    $obj->phone          =   $request->phone;
                    $obj->address        =   $request->address;
                    $obj->about          =   $request->about;
                    $obj->email          =   $request->email;
                    $obj->name           =   $request->name;
                    $obj->save();

                return redirect()->route('profile')->with('success','Profile updated successfully');
             }else{
                return back()->with('error','Something went wrong');  
             }


        }catch(\Throwable $th){ 
            dd($th);   
            return redirect()->back()->with('error','Something went wrong');
        }


   }

    


}
