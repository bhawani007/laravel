<?php

namespace App\Imports;

use App\Models\Product;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class ProductsImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {

        $obj =  Product::where('barcode', $row['barcode'])->first();
        if(!$obj)
        {
         $obj = new Product;
        } 
      
        try{

        $obj->name                   	= $row['product_name'];
        $obj->type                 		= $row['type'];
        $obj->barcode             		= $row['barcode'];
        $obj->serving_bowl              = $row['serving_bowl'];
        $obj->serving_unit          	= $row['serving_unit'];
        $obj->calories              	= $row['calories']; 
        $obj->total_fat         		= $row['total_fat'];
        $obj->total_fat_unit            = $row['fat_unit'];
        $obj->sodium          		 	= $row['sodium'];
        $obj->sodium_unit  			 	= $row['sodium_unit'];
        $obj->saturated_fat             = $row['saturated_fat'];
        $obj->saturated_fat_unit        = $row['saturated_fat_unit'];
        $obj->trans_fat                 = $row['trans_fats'];	
        $obj->trans_fats_unit           = $row['trans_fats_unit'];	
        $obj->cholesterol               = $row['cholestrol'];	
        $obj->cholestrol_unit           = $row['cholestrol_unit'];	
        $obj->total_carbohydrates       = $row['total_carbohydrates'];	
        $obj->total_carbohydrates_unit  = $row['total_carbohydrates_unit'];
        $obj->dietry_fibres             = $row['dietry_fibres'];
        $obj->dietry_fibres_unit        = $row['dietry_fibres_unit'];
        $obj->total_sugars              = $row['total_sugars'];
        $obj->total_sugars_unit         = $row['total_sugars_unit'];
        $obj->added_sugars              = $row['added_sugars'];
        $obj->added_sugars_unit         = $row['added_sugars_unit'];
        $obj->protein                   = $row['protein'];
        $obj->protein_unit              = $row['protein_unit'];
        $obj->vitamin_d                 = $row['vitamin_d'];
        $obj->calcium                   = $row['calcium'];
        $obj->iron            		    = $row['iron'];
        $obj->vitamin_c          		= $row['vitamin_c'];
        $obj->potassium          		= $row['potassium'];
        $obj->potassium_unit            = $row['potassium_unit'];
        $obj->daily_value          		= $row['daily_value_dv'];
        $obj->save();

        }catch(\throwable $th){
            dd($th);
        } 				
    }
}
