<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;
use App\Models\UserProfile;
use App\Models\Goal;
use Spatie\Permission\Models\Role;
use Hash;
Use Auth;
use App\Http\Controllers\API\BaseController;




class User extends Authenticatable
{
    use HasFactory, Notifiable, HasApiTokens, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


    public function add($user){  
      try{
        $usr = explode('@', $user['email']);
        $obj                      =    new User();
        $obj->name                =    $user['name'];
        $obj->username            =    $usr[0];
        $obj->email               =    $user['email'];
        if(isset($user['device_type'])) {
          $obj->device_type               =    $user['device_type'];
          $obj->device_token              =    $user['device_token'];
        }

        if(isset($user['password'])){
          $obj->password                   =    $user['password'];
          $random_pass                     =    $user['password'];
        }else{
          $random_pass                      =  $this->generateRandomString();
        }

        $obj->password                    =    Hash::make($random_pass);
        $obj->save();
        $userId = $obj->id;
        $obj->assignRole($user['role']);
        
        $objProfile               =  New UserProfile();
        $objProfile->user_id      =  $userId;  
        $objProfile->dob          =  isset($user['dob'])?$user['dob']:'2012-11-29';  
        $objProfile->gender       =  isset($user['gender'])?$user['gender']:'Other';  
        $objProfile->height       =  isset($user['height'])?$user['height']:'';  
        $objProfile->weight       =  isset($user['weight'])?$user['weight']:'';
        $objProfile->weight       =  isset($user['weight'])?$user['weight']:'';
        $objProfile->weight       =  isset($user['weight'])?$user['weight']:'';
        $objProfile->weight       =  isset($user['weight'])?$user['weight']:'';
        $objProfile->weight       =  isset($user['weight'])?$user['weight']:'';
        $objProfile->weight       =  isset($user['weight'])?$user['weight']:'';
        $objProfile->save();  

        return array('status'=>1,'UserId'=>$userId,'password'=>$random_pass,'return'=>$obj);

      }catch(\Throwable $th){ 
        dd($th); 
         return array('status'=>0,'UserId'=>0,'return'=>'','password'=>$random_pass);
      }    

    }

    public function updateUser($user, $userId){  
          try{
            $obj                      =    User::find($userId);
            $obj->name                =    $user['name'];
            if(isset($user['email'])){
              $usr                      =    explode('@', $user['email']);
              $obj->username            =    $usr[0];
              $obj->email               =    $user['email'];
            }

            if(isset($user['device_token']))
            $obj->device_token        =    $user['device_token'];
            $obj->save();
            $ProId = $obj->id;
        
            $objProfile                      =  UserProfile::where('user_id',$ProId)->first();
            $objProfile->dob                 =  isset($user['dob'])?$user['dob']:'2012-11-29';  
            $objProfile->gender              =  isset($user['gender'])?$user['gender']:'Other';  
            $objProfile->height              =  isset($user['height'])?$user['height']:'';  
            $objProfile->weight              =  isset($user['weight'])?$user['weight']:'';
            $objProfile->activity_level      =  isset($user['activity_level'])?$user['activity_level']:'Normal';
            $objProfile->weight_goal_id      =  isset($user['weight_goal_id'])?$user['weight_goal_id']:'0';
            $objProfile->exercise_routine_id =  isset($user['exercise_routine_id'])?$user['exercise_routine_id']:'0';
            $objProfile->food_habit_id       =  isset($user['food_habit_id'])?$user['food_habit_id']:'0';
            $objProfile->calorie_min         =  isset($user['calorie_min'])?$user['calorie_min']:'0';
            $objProfile->calorie_max         =  isset($user['calorie_max'])?$user['calorie_max']:'0';
            $objProfile->save();  
    
            return array('status'=>1,'UserId'=>$userId);
    
          }catch(\Throwable $th){  
             return array('status'=>0,'UserId'=>0);
          }    
    }


    public function changePass($user, $id){
        try{
         $obj                 =   User::find($id);
         $obj->password       =   hash::make($user['password']);
         $obj->save();
         return array('status'=>1,'name'=>$obj->name,'email'=>$obj->email,'password'=>$user['password']);
        }catch(\Throwable $th){
          return array('status'=>0);
        }
    }


    public function profile(){
       return $this->hasOne(UserProfile::class,'user_id','id');
    }


    public function login($data){ 
      $email            =     $data['email'];
      $password         =     $data['password'];

      try{
        if(Auth::attempt(array('email' => $email, 'password' => $password))){
          return array('status' => 1,'UserId' => Auth::user()->id);
        }
        else{
          return array('status' => 0,'UserId' => 0);
        }
      }catch(\Throwable $th){
        return array('status'=>0,'UserId'=>0);
      } 
    }

   public function forgotPass($data){  
     try{
          $obj   =   User::where('email', $data['email'])->first();
          if($obj){  
            $baseobj     =  new BaseController();
            $otp         =  $baseobj->generateNumericOTP();

            $recNo      =  $this->recursiveOTP($otp);
            if($recNo){
            $obj->otp  =  $recNo;
            $obj->save();
            return array('status' => 1,'otp' => $obj);
          }
        }else{
          return array('status' => 0,'otp' => '');
          }
      }catch(\Throwable $th){
          return array('status' => 0,'otp' => '');
      }          
   }


   private function recursiveOTP($data){ 
      $countop   =   User::where('otp', $data)->count();
      if($countop  == 0){
         return $data;
      }else{
        $baseobj     =  new BaseController();
        $otp         =  $baseobj->generateNumericOTP();
        $this->recursiveOTP($otp);
      }
   }
   
   
   public function resetPass($data){ 
     try{
        $obj  =  User::where('email', $data['email'])->where('otp', $data['otp'])->first();
        if($obj){
          $obj->otp           =   ""; 
          $obj->password      =   hash::make($data['password']); 
          $obj->save();    
          return array('status' => 1,'msg' => 'Password reset successfully','data' =>  $obj);
        }else{
          return array('status' => 0,'msg' => 'Data not match','data' =>  $obj);
        }
     }catch(\Throwable $th){
         return array('status' => 0);
     } 
   }


    public function generateRandomString($length = 8){
      $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $charactersLength = strlen($characters);
      $randomString     = '';
      for ($i = 0; $i < $length; $i++) {
          $randomString .= $characters[rand(0, $charactersLength - 1)];
      }
      return $randomString;
    }

    public function SocialLog($data){

     try{ 
      if($data['email']){
        $obj           =  User::where('email', $data['email'])->first();
      }
      else if($data['social_type']=='facebook') {
        $obj           =  User::where('facebook_id', $data['facebook_token'])->first();
      }else{
        $obj           =  User::where('google_id', $data['google_token'])->first();
      }

      if($obj){
          $obj->name   = isset($data['name'])?$data['name']:'';
          $obj->email  = isset($data['email'])?$data['email']:'';
          if($data['social_type']=='facebook'){
          $obj->facebook_id   = $data['facebook_token'];
          }else{  
          $obj->google_id   = $data['google_token'];
          }
          $obj->save();
          
      }else{
         $obj         = new User();
         $obj->name   = isset($data['name'])?$data['name']:'';
         $obj->email  = isset($data['email'])?$data['email']:'';
         if($data['social_type']=='facebook'){
          $obj->facebook_id   = $data['facebook_token'];
         }else{  
          $obj->google_id   = $data['google_token'];
         }
         $obj->save();
         $obj->assignRole('user');
      }
      return array('status' => 1,'msg' => 'User registed successfully','data' => $obj);
      }catch(\Throwable $th){
      return array('status' => 0);
      } 

    }

}
