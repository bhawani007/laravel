<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\User;
use DNS1D, Storage;

class Product extends Model
{
    use HasFactory;


    public function Step1($data, $fileexist=0)
    {			
      try{
			$obj  = Product::where('barcode',$data['barcode'])->first();
			  
			if(!$obj)
			{
			  $obj  = new Product;
			}

			//$obj                       	= new Product;
			$obj->name                   	= isset($data['name'])?$data['name']:'';
			$obj->added_by                  = isset($data['added_by'])?$data['added_by']:0;
			$obj->size                 		= isset($data['size'])?$data['size']:'';
			$obj->category             		= isset($data['category'])?$data['category']:'';
			$obj->type                   	= isset($data['type'])?$data['type']:0;
			$obj->serving_bowl           	= isset($data['serving_bowl'])?$data['serving_bowl']:0;
			$obj->serving_unit           	= isset($data['serving_unit'])?$data['serving_unit']:'';
			$obj->calories              	= isset($data['calories'])?$data['calories']:0;
			//$obj->image                	= $fileName;
			$obj->total_fat         		= isset($data['total_fat'])?$data['total_fat']:0;
			$obj->total_fat_unit         	= isset($data['total_fat_unit'])?$data['total_fat_unit']:'';
			$obj->sodium          		 	= isset($data['sodium'])?$data['sodium']:0;
			$obj->sodium_unit  			 	= isset($data['sodium_unit'])?$data['sodium_unit']:'';
			$obj->barcode       		 	= isset($data['barcode'])?$data['barcode']:'';
			$obj->barcode_type       		= isset($data['barcode_type'])?$data['barcode_type']:'';
			$obj->saturated_fat          	= isset($data['saturated_fat'])?$data['saturated_fat']:0;
			$obj->saturated_fat_unit     	= isset($data['saturated_fat_unit'])?$data['saturated_fat_unit']:'';
			$obj->trans_fat              	= isset($data['trans_fat'])?$data['trans_fat']:0;
			$obj->trans_fats_unit        	= isset($data['trans_fats_unit'])?$data['trans_fats_unit']:'';
			$obj->cholesterol            	= isset($data['cholesterol'])?$data['cholesterol']:0;
			$obj->cholestrol_unit        	= isset($data['cholestrol_unit'])?$data['cholestrol_unit']:'';
			$obj->total_carbohydrates    	= isset($data['total_carbohydrates'])?$data['total_carbohydrates']:0;
			$obj->total_carbohydrates_unit  = isset($data['total_carbohydrates_unit'])?$data['total_carbohydrates_unit']:'';
			$obj->dietry_fibres             = isset($data['dietry_fibres'])?$data['dietry_fibres']:0;
			$obj->dietry_fibres_unit        = isset($data['dietry_fibres_unit'])?$data['dietry_fibres_unit']:'';
			$obj->total_sugars              = isset($data['total_sugars'])?$data['total_sugars']:0;
			$obj->total_sugars_unit         = isset($data['total_sugars_unit'])?$data['total_sugars_unit']:'';
			$obj->added_sugars              = isset($data['added_sugars'])?$data['added_sugars']:0;
			$obj->added_sugars_unit         = isset($data['added_sugars_unit'])?$data['added_sugars_unit']:'';
			$obj->protein                   = isset($data['protein'])?$data['protein']:0;
			$obj->protein_unit              = isset($data['protein_unit'])?$data['protein_unit']:'';
			$obj->vitamin_d                 = isset($data['vitamin_d'])?$data['vitamin_d']:0;
			$obj->calcium                   = isset($data['calcium'])?$data['calcium']:0;
			$obj->iron            		    = isset($data['iron'])?$data['iron']:0;
			$obj->vitamin_c          		= isset($data['vitamin_c'])?$data['vitamin_c']:0;
			$obj->potassium          		= isset($data['potassium'])?$data['potassium']:0;
			$obj->potassium_unit            = isset($data['potassium_unit'])?$data['potassium_unit']:'';
			$obj->daily_value          		= isset($data['daily_value'])?$data['daily_value']:0;
			$obj->save();
			$last_id = $obj->id;

			$img = $text =  $this->base64txt($data['barcode']);
			$img = str_replace('data:image/png;base64,', '', $img);
			$img = str_replace(' ', '+', $img);
			$data11 = base64_decode($img);

			if(!Storage::exists('/public/'.$last_id)) 
			{
			  Storage::makeDirectory('/public/'.$last_id, 0775, true); //creates directory
			}
			
			Storage::disk('public')->put($last_id.'/'.$last_id.'.png', $data11);
		  
			$fileName='';
			if($fileexist == 1)
			{  
				ProductImage::where('product_id',$last_id)->delete();

				foreach($data['image'] as $key => $value) 
				{   
					$rand = rand(1,1000000);
					$fileName = time().$rand.'.'.$value->extension();  
					$value->move(public_path('products'), $fileName);

					$obj1              = new ProductImage;
					$obj1->product_id  = $last_id;
					$obj1->image       = $fileName;
					$obj1->save();
				}
			}

		 return ["status"=>1,"data"=>$last_id];
	    }
	    catch(\Throwable $th){
          return ["status"=>0,"data"=>''];
	   }
	}

    public function base64txt($code)
	{
	 return "data:image/png;base64,".DNS1D::getBarcodePNG($code, 'C128',1,70);
	}
	

	public function getImages()
	{
		return $this->hasMany(ProductImage::class,"product_id");
	}

	public function profile()
	{
		return $this->belongsTo(User::class,'added_by','id');
	}

    // public function Step2($data, $id)
    // {
    //   try{
    
	// 	$obj                       = Product::find($id);
	// 	$obj->saturated_fat        = $data['saturated_fat'];
	// 	$obj->trans_fat            = $data['trans_fat'];
	// 	$obj->cholesterol          = $data['cholesterol'];
	// 	$obj->total_carbohydrates  = $data['total_carbohydrates'];
	// 	$obj->dietary_fibres       = $data['dietary_fibres'];
	// 	$obj->total_sugars         = $data['total_sugars'];
	// 	$obj->added_sugars         = $data['added_sugars'];
	// 	$obj->save();

	// 	return ["status"=>1,"data"=>$id];
	//     }
	//    catch(\Throwable $th){
    //     return ["status"=>0,"data"=>''];
	//    }

    // }

    // public function Step3($data, $id)
    // {
    //   try{
    
	// 	$obj                 = Product::find($id);
	// 	$obj->protein        = $data['protein'];
	// 	$obj->vitamin_d      = $data['vitamin_d'];
	// 	$obj->calcium        = $data['calcium'];
	// 	$obj->iron           = $data['iron'];
	// 	$obj->vitamin_c      = $data['vitamin_c'];
	// 	$obj->potassium      = $data['potassium'];
	// 	$obj->daily_value    = $data['daily_value'];
	// 	$obj->save();

	// 	return ["status"=>1,"data"=>$id];
	//     }
	//    catch(\Throwable $th){
	//    	dd($th);
    //     return ["status"=>0,"data"=>''];
	//    }

    // }
}
