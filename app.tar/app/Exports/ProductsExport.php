<?php
namespace App\Exports;
use App\Models\Product;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ProductsExport implements FromCollection, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //return Product::all();

       return Product::select('id', 'name', 'type', 'barcode', 'serving_bowl', 'serving_unit', 'calories', 'total_fat', 'total_fat_unit', 'sodium', 'sodium_unit', 'barcode', 'saturated_fat', 'saturated_fat_unit', 'trans_fat', 'trans_fats_unit', 'cholesterol', 'cholestrol_unit', 'total_carbohydrates', 'total_carbohydrates_unit', 'dietry_fibres', 'dietry_fibres_unit', 'total_sugars', 'total_sugars_unit', 'added_sugars', 'added_sugars_unit', 'protein' , 'protein_unit', 'vitamin_d', 'calcium', 'iron', 'vitamin_c', 'potassium', 'potassium_unit', 'daily_value')
        ->get();
    }

    public function headings(): array
    {
        return [
            // 'Id',
            // 'Product Name',
            // 'Serving Size',
            // 'category',
            // 'total_fat',
            // 'sodium',
            // 'barcode',
            // 'image',
            // 'created_at',
            // 'updated_at',
            // 'saturated_fat',
            // 'trans_fat',
            // 'cholesterol',
            // 'total_carbohydrates',
            // 'dietary_fibres',
            // 'total_sugars',
            // 'added_sugars',
            // 'protein',
            // 'vitamin_d',
            // 'calcium',
            // 'iron',
            // 'vitamin_c',
            // 'potassium',
            // 'daily_value',


            'Id',
            'Product Name',
            'Type',
            'Barcode',
            'Serving Bowl',
            'Serving (Unit)',
            'Calories',
            'Total Fat',
            'Fat (Unit)',
            'Sodium',
            'Sodium (Unit)',
            'Saturated Fat',
            'Saturated Fat (unit)',
            'Trans Fats',
            'Trans Fats (unit)',
            'Cholestrol',
            'Cholestrol (Unit)',
            'Total Carbohydrates',
            'Total Carbohydrates (unit)',
            'Dietry Fibres',
            'Dietry Fibres (unit)',
            'Total Sugars',
            'Total Sugars (Unit)',
            'Added Sugars',
            'Added Sugars (unit)',
            'Protein',
            'Protein (unit)',
            'Vitamin D',
            'Calcium (%)',
            'Iron (%)',
            'Vitamin C',
            'Potassium',
            'Potassium (unit)',
            'Daily Value (DV) (%)'
        ];
    }
}
