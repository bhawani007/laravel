<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\ProductController;
use App\Http\Controllers\API\UserController;
use App\Http\Controllers\API\MembershipController;
use App\Http\Controllers\API\ExerciseController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


//user
Route::post('/register', [UserController::class, 'register']);
Route::post('/login', [UserController::class, 'login']);
Route::post('/forgot-password',[UserController::class, 'forgotPassword']);
Route::post('/reset-password',[UserController::class, 'resetPassword']);
Route::get('/goals-list', [UserController::class, 'goalList']);
Route::post('/verify-otp',[UserController::class, 'verifyOTP']);
Route::post('/resend-otp',[UserController::class, 'forgotPassword']);

Route::group(['middleware' => ['auth:api']], function () {

    Route::post('/update-photo', [UserController::class, 'UpdatePhoto']);
    Route::patch('/view-profile', [UserController::class, 'viewProfile']);
    Route::post('/update-profile', [UserController::class, 'updateProfile']);
    Route::post('/change-password', [UserController::class, 'changePassword']);
    Route::post('/user-view-video',[UserController::class, 'userViewVideo']);
    

});

Route::post('/social-login',[UserController::class, 'socialLogin']);

//membership
Route::post('/add-membership',[MembershipController::class, 'add']);
Route::patch('/all-membership',[MembershipController::class, 'allMembership']);
Route::patch('/view-membership/{id}',[MembershipController::class, 'viewMembership']);
Route::post('/edit-membership/{id}',[MembershipController::class, 'edit']);
Route::delete('/delete-membership/{id}',[MembershipController::class, 'destroy']);

//product
Route::post('/add-product', [ProductController::class, 'storestep1']);
Route::get('/list-product', [ProductController::class, 'index']);

//exercise
Route::get('/exercises',[ExerciseController::class,'index']);



