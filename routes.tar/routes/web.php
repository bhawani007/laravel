<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Admin\UserController as AdminUser;
use App\Http\Controllers\Admin\SystemSettingController;
use App\Http\Controllers\Admin\CmsPageController;
use App\Http\Controllers\Admin\MembershipController;
use App\Http\Controllers\Admin\ExerciseController;
use App\Http\Controllers\Admin\SubExerciseController;
use App\Http\Controllers\Admin\NotificationController;
use App\Http\Controllers\Admin\GoalController;
use App\Http\Controllers\Admin\RoutingController;
use App\Http\Controllers\Admin\HabbitController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    //return view('welcome');
    if(Auth::check()){
        return view('admin.dashboard');
    }
    else{ 
        return view('admin.index');
    }
});

Auth::routes();

//Route::get('/', [App\Http\Controllers\HomeController::class, 'index']);
Route::get('/login', [App\Http\Controllers\UserController::class, 'index'])->name('login');
Route::get('/guest-forgot-password', [App\Http\Controllers\UserController::class, 'forgotPassword'])->name('guest-forgot-password');
Route::post('/forgot-password', [App\Http\Controllers\UserController::class, 'forgotPasswordData'])->name('forgot-password');
Route::get('/reset-password/{token}', [App\Http\Controllers\UserController::class, 'resetPassword'])->name('reset-password');
Route::post('/reset-password-data', [App\Http\Controllers\UserController::class, 'resetPasswordData'])->name('reset-password-data');
Route::post('/login', [App\Http\Controllers\UserController::class, 'login'])->name('login');
Route::get('/logout', [App\Http\Controllers\UserController::class, 'logout'])->name('logout');


Route::group(['prefix' => 'admin', 'middleware' => 'auth'], function()
{
    Route::get('/dashboard', [App\Http\Controllers\UserController::class, 'dashboard'])->name('dashboard');
    Route::get('/profile', [App\Http\Controllers\UserController::class, 'profile'])->name('profile');
    Route::get('/profile-edit', [App\Http\Controllers\UserController::class, 'editProfile'])->name('profile.edit');
    Route::post('/profile-update', [App\Http\Controllers\UserController::class, 'updateProfile'])->name('profile.update');
    Route::get('/product', [App\Http\Controllers\ProductController::class, 'index'])->name('product.index');
    Route::get('/product-add', [App\Http\Controllers\ProductController::class, 'add'])->name('product.add');
    Route::get('/barcode', [App\Http\Controllers\ProductController::class, 'barcode'])->name('barcode');
    Route::post('/product-store', [App\Http\Controllers\ProductController::class, 'store'])->name('product.store');
    Route::get('/product-import-data', [App\Http\Controllers\ProductController::class, 'importData'])->name('product.import.data');
    Route::post('/product-import', [App\Http\Controllers\ProductController::class, 'import'])->name('product.import');
    Route::get('/product.export', [App\Http\Controllers\ProductController::class, 'export'])->name('product.export');
    Route::get('/product-view/{id}', [App\Http\Controllers\ProductController::class, 'show'])->name('product.view');
    Route::get('/product-edit/{id}', [App\Http\Controllers\ProductController::class, 'edit'])->name('product.edit');
    Route::post('/product-update/{id}', [App\Http\Controllers\ProductController::class, 'update'])->name('product.update');
    Route::get('/product-delete/{id}', [App\Http\Controllers\ProductController::class, 'destroy'])->name('product.delete');
    
    //user routing
    Route::get('/user', [AdminUser::class, 'index'])->name('user.index');
    Route::get('user-add',[AdminUser::class, 'create'])->name('user.add');
    Route::post('user-store',[AdminUser::class, 'store'])->name('user.store');
    Route::get('user-edit/{id}',[AdminUser::class, 'edit'])->name('user.edit');
    Route::post('user-update/{id}',[AdminUser::class, 'update'])->name('user.update');
    Route::get('user-delete/{id}',[AdminUser::class,'delete'])->name('user.delete');
    Route::get('user-view-video-delete/{userid}/{videoid}',[AdminUser::class,'deleteVideo'])->name('user.view.video.delete');
    Route::get('user-view/{id}',[AdminUser::class,'show'])->name('user.view');
    Route::post('user-changepassword/{id}',[AdminUser::class,'changePassword'])->name('user.changepassword');
    
    //systen setting
    Route::get('system-setting',[SystemSettingController::class,'index'])->name('system.setting');
    Route::post('system-setting',[SystemSettingController::class,'store'])->name('system.setting.store');

    //cms pages
    Route::resource('cms-pages', CmsPageController::class);
    Route::get('cms-page-delete/{id}',[CmsPageController::class,'delete'])->name('cms.page.delete');

    //membership 
    Route::resource('membership', MembershipController::class);
    Route::get('membership-delete/{id}',[MembershipController::class,'destroy'])->name('membership.delete');

    //exercise 
    Route::resource('exercises', ExerciseController::class);
    Route::get('exercise-delete/{id}',[ExerciseController::class,'destroy'])->name('exercises.delete');

    //exercise 
    Route::resource('sub-exercise', SubExerciseController::class);
    Route::get('sub-exercise-delete/{id}',[SubExerciseController::class,'destroy'])->name('sub.exercises.delete');
    Route::post('sub-exercise',[SubExerciseController::class, 'store'])->name('sub-exercise.store');
    Route::post('sub-exercise-update',[SubExerciseController::class, 'update'])->name('sub-exercise.update');

    //notification
    Route::get('notifications', [NotificationController::class,'index'])->name('notification.index');
    route::get('notification-delete/{id}', [NotificationController::class,'destroy'])->name('notification.delete');

    Route::resource('goals', GoalController::class);
    route::get('goal-delete/{id}', [GoalController::class,'delete'])->name('goals.delete');

    Route::resource('goal-routines', RoutingController::class);
    route::get('goal-routine-delete/{id}', [RoutingController::class,'delete'])->name('goals.routine.delete');

    Route::resource('goal-habits', HabbitController::class);
    route::get('goal-habits-delete/{id}', [HabbitController::class,'delete'])->name('goals.habits.delete');



});

